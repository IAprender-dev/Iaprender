import { useState, useEffect, useRef } from 'react'
import axios from 'axios'
import { jsPDF } from 'jspdf'
import { gapi } from 'gapi-script'

const CLIENT_ID = '709799557322-u8b85k6j9pbkopap4ngn63an2853ejt2.apps.googleusercontent.com'
const SCOPE = 'https://www.googleapis.com/auth/drive.file'

const DISCIPLINAS = [
  "Matemática", "Português", "Ciências", "História", "Geografia", "Inglês", "Artes", "Física", "Química", "Biologia"
];

const TIPOS_ENSINO = [
  "Ensino Fundamental I", "Ensino Fundamental II", "Ensino Médio", "Pré-vestibular", "Outros"
];

const ANOS_SERIES = {
  "Ensino Fundamental I": ["1º ano", "2º ano", "3º ano", "4º ano", "5º ano"],
  "Ensino Fundamental II": ["6º ano", "7º ano", "8º ano", "9º ano"],
  "Ensino Médio": ["1ª série", "2ª série", "3ª série"],
  "Pré-vestibular": ["Pré-vestibular"],
  "Outros": ["Outro"]
};

const DICAS = [
  "Peça para a tutora explicar passo a passo.",
  "Solicite exemplos práticos para facilitar o entendimento.",
  "Peça dicas de estudo para provas e trabalhos.",
  "Peça para resumir um conteúdo difícil.",
  "Peça sugestões de exercícios para praticar.",
];

const SUGESTOES_PERGUNTA = [
  "Pode me ajudar a entender frações?",
  "Como faço um resumo eficiente?",
  "Explique a diferença entre mitose e meiose.",
  "Quais dicas para estudar matemática?",
  "Como organizar meu tempo de estudo?",
  "Me dê um exemplo de redação nota 10.",
  "Explique o que é energia renovável.",
  "Como resolver uma equação do 2º grau?",
  "O que foi a Revolução Industrial?",
];

const MODOS_ATENDIMENTO = [
  "Atendimento Geral",
  "Motivar Aluno",
  "Revisão de Conteúdo",
  "Tirar Dúvida Específica",
  "Ensinar do Zero",
];

const gerarPromptSistema = (disciplina, tipoEnsino, anoSerie, modoAtendimento) => {
  const base = `Você é a Professora IAula, uma tutora virtual especializada em ${disciplina}, para ${anoSerie} do ${tipoEnsino}.`;

  switch (modoAtendimento) {
    case "Motivar Aluno":
      return `${base} Sua missão é motivar o aluno com mensagens positivas, incentivar seus esforços e mostrar que todas as dificuldades podem ser superadas. Seja acolhedora e entusiasmada.`;
    case "Revisão de Conteúdo":
      return `${base} Faça uma revisão clara e resumida do conteúdo, destacando os principais pontos, com dicas rápidas para memorização e mini testes.`;
    case "Tirar Dúvida Específica":
      return `${base} Ajude o aluno a tirar uma dúvida específica de forma didática e paciente, explicando passo a passo com exemplos.`;
    case "Ensinar do Zero":
      return `${base} Ensine o conteúdo como se o aluno estivesse aprendendo do zero, com linguagem simples, exemplos práticos e muita paciência.`;
    default:
      return `${base} Responda de forma didática, paciente, acolhedora e motivadora. Explique passo a passo, dê exemplos práticos e dicas de estudo sempre que possível.`;
  }
};

function AjudaModal({ open, onClose }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black bg-opacity-40">
      <div className="bg-white rounded-lg p-6 max-w-md w-full shadow-lg relative">
        <button
          aria-label="Fechar ajuda"
          onClick={onClose}
          className="absolute top-2 right-2 text-gray-400 hover:text-gray-700 text-xl"
        >×</button>
        <h2 className="text-xl font-bold mb-2">Como usar a Tutora Virtual</h2>
        <ul className="list-disc pl-5 space-y-2 text-sm">
          <li>Escolha a disciplina, o tipo de ensino e o ano/série para personalizar sua tutora.</li>
          <li>Peça explicações detalhadas sobre qualquer conteúdo escolar.</li>
          <li>Use o botão <b>Surpreenda-me</b> para sugestões de perguntas.</li>
          <li>Copie respostas para seus resumos ou trabalhos.</li>
          <li>Salve ou envie a conversa para o Google Drive.</li>
          <li>Limpe o histórico quando quiser começar uma nova conversa.</li>
        </ul>
      </div>
    </div>
  );
}

export default function TutorVirtual() {
  const [disciplina, setDisciplina] = useState(DISCIPLINAS[0]);
  const [tipoEnsino, setTipoEnsino] = useState(TIPOS_ENSINO[0]);
  const [anoSerie, setAnoSerie] = useState(ANOS_SERIES[TIPOS_ENSINO[0]][0]);
  const [modoAtendimento, setModoAtendimento] = useState(MODOS_ATENDIMENTO[0]);
  const [pergunta, setPergunta] = useState('');
  const [historico, setHistorico] = useState([]);
  const [carregando, setCarregando] = useState(false);
  const [googleSignedIn, setGoogleSignedIn] = useState(false);
  const [erro, setErro] = useState('');
  const [ajudaAberta, setAjudaAberta] = useState(false);
  const [sucesso, setSucesso] = useState('');
  const endRef = useRef(null);

  useEffect(() => {
    const historicoSalvo = localStorage.getItem('tutoraHistorico');
    if (historicoSalvo) setHistorico(JSON.parse(historicoSalvo));
    gapi.load('client:auth2', initClient);
  }, []);

  useEffect(() => {
    if (endRef.current) endRef.current.scrollIntoView({ behavior: 'smooth' });
  }, [historico]);

  useEffect(() => {
    setAnoSerie(ANOS_SERIES[tipoEnsino][0]);
  }, [tipoEnsino]);

  const initClient = () => {
    gapi.client.init({
      clientId: CLIENT_ID,
      scope: SCOPE,
    }).then(() => {
      const auth = gapi.auth2.getAuthInstance();
      setGoogleSignedIn(auth.isSignedIn.get());
      auth.isSignedIn.listen(setGoogleSignedIn);
    });
  };

  const handleLoginGoogle = () => {
    const auth = gapi.auth2.getAuthInstance();
    auth.signIn();
  };

  const enviarPergunta = async () => {
    if (!pergunta.trim()) return;
    setErro('');
    setSucesso('');
    const novaPergunta = pergunta.trim();
    setPergunta('');
    setCarregando(true);

    try {
      const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-3.5-turbo',
          messages: [
            {
              role: 'system',
              content: gerarPromptSistema(disciplina, tipoEnsino, anoSerie, modoAtendimento),
            },
            { role: 'user', content: novaPergunta }
          ],
          temperature: 0.7,
        },
        {
          headers: {
            Authorization: `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
          },
        }
      );

      const respostaIA = response.data.choices[0].message.content;
      const novoItem = { pergunta: novaPergunta, resposta: respostaIA, disciplina, tipoEnsino, anoSerie };
      const novoHistorico = [...historico, novoItem];
      setHistorico(novoHistorico);
      localStorage.setItem('tutoraHistorico', JSON.stringify(novoHistorico));
      setSucesso('Resposta da tutora recebida!');
    } catch (error) {
      setErro('Erro ao buscar resposta da Tutora. Tente novamente.');
      const novoItemErro = { pergunta: novaPergunta, resposta: 'Erro ao buscar resposta da Tutora. Tente novamente.', disciplina, tipoEnsino, anoSerie };
      const novoHistorico = [...historico, novoItemErro];
      setHistorico(novoHistorico);
      localStorage.setItem('tutoraHistorico', JSON.stringify(novoHistorico));
    } finally {
      setCarregando(false);
      setTimeout(() => setSucesso(''), 2000);
    }
  };

  const limparHistorico = () => {
    if (window.confirm('Tem certeza que deseja limpar a conversa?')) {
      setHistorico([]);
      localStorage.removeItem('tutoraHistorico');
    }
  };

  const baixarConversaPdf = () => {
    if (historico.length === 0) {
      setErro('Nenhuma conversa para baixar.');
      return;
    }
    const doc = new jsPDF();
    let y = 10;
    historico.forEach((item) => {
      doc.setFontSize(12);
      doc.text(`Você (${item.disciplina}, ${item.anoSerie}, ${item.tipoEnsino}): ${item.pergunta}`, 10, y);
      y += 10;
      doc.text(`Professora IAula: ${item.resposta}`, 10, y);
      y += 20;
      if (y > 270) {
        doc.addPage();
        y = 10;
      }
    });
    doc.save('conversa-tutora.pdf');
    setSucesso('PDF baixado com sucesso!');
    setTimeout(() => setSucesso(''), 2000);
  };

  const copiarResposta = (resposta) => {
    navigator.clipboard.writeText(resposta);
    setSucesso('Resposta copiada para a área de transferência!');
    setTimeout(() => setSucesso(''), 2000);
  };

  const sugestaoPergunta = () => {
    const aleatorio = SUGESTOES_PERGUNTA[Math.floor(Math.random() * SUGESTOES_PERGUNTA.length)];
    setPergunta(aleatorio);
  };

  const uploadPdfParaGoogleDrive = async () => {
    if (historico.length === 0) {
      setErro('Nenhuma conversa para enviar.');
      return;
    }
    const doc = new jsPDF();
    let y = 10;
    historico.forEach((item) => {
      doc.setFontSize(12);
      doc.text(`Você (${item.disciplina}, ${item.anoSerie}, ${item.tipoEnsino}): ${item.pergunta}`, 10, y);
      y += 10;
      doc.text(`Professora IAula: ${item.resposta}`, 10, y);
      y += 20;
      if (y > 270) {
        doc.addPage();
        y = 10;
      }
    });

    const pdfBlob = doc.output('blob');
    const accessToken = gapi.auth2.getAuthInstance().currentUser.get().getAuthResponse().access_token;

    try {
      const searchResponse = await fetch('https://www.googleapis.com/drive/v3/files?q=name="IAula"+and+mimeType="application/vnd.google-apps.folder"+and+trashed=false', {
        headers: new Headers({ Authorization: `Bearer ${accessToken}` }),
      });
      const searchData = await searchResponse.json();
      let folderId = null;
      if (searchData.files && searchData.files.length > 0) {
        folderId = searchData.files[0].id;
      } else {
        const folderMetadata = {
          name: 'IAula',
          mimeType: 'application/vnd.google-apps.folder',
        };
        const folderResponse = await fetch('https://www.googleapis.com/drive/v3/files', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(folderMetadata),
        });
        const folderData = await folderResponse.json();
        folderId = folderData.id;
      }

      const metadata = {
        name: 'conversa-tutora.pdf',
        parents: [folderId],
        mimeType: 'application/pdf',
      };

      const form = new FormData();
      form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
      form.append('file', pdfBlob);

      const uploadResponse = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
        method: 'POST',
        headers: new Headers({ Authorization: `Bearer ${accessToken}` }),
        body: form,
      });

      if (uploadResponse.ok) {
        setSucesso('Conversa salva como PDF na pasta IAula no Google Drive!');
      } else {
        setErro('Erro ao enviar o PDF para o Drive.');
      }
    } catch (error) {
      setErro('Erro inesperado ao salvar no Google Drive.');
    }
    setTimeout(() => {
      setErro('');
      setSucesso('');
    }, 2000);
  };

  return (
    <div className="flex flex-col h-full p-6 sm:p-10 gap-6 max-w-6xl mx-auto w-full">
      <AjudaModal open={ajudaAberta} onClose={() => setAjudaAberta(false)} />

      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-2">
        <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
          👩‍🏫 Tutora Virtual
          <span className="text-xs bg-pink-100 text-pink-700 px-2 py-1 rounded">Beta</span>
          <button
            aria-label="Ajuda"
            onClick={() => setAjudaAberta(true)}
            className="px-2 py-1 bg-pink-50 text-pink-700 rounded hover:bg-pink-100 text-xs font-semibold"
          >
            Ajuda
          </button>
        </h1>
        <div className="flex flex-wrap gap-3">
          {!googleSignedIn && (
            <button
              onClick={handleLoginGoogle}
              className="px-5 py-3 text-base rounded-lg bg-yellow-500 text-white hover:bg-yellow-600 transition"
            >
              Conectar Google Drive
            </button>
          )}
          {googleSignedIn && (
            <button
              onClick={uploadPdfParaGoogleDrive}
              className="px-5 py-3 text-base rounded-lg bg-green-600 text-white hover:bg-green-700 transition"
            >
              Salvar PDF no Drive
            </button>
          )}
          <button
            onClick={baixarConversaPdf}
            className="px-5 py-3 text-base rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition"
          >
            Baixar PDF
          </button>
          <button
            onClick={limparHistorico}
            className="px-5 py-3 text-base rounded-lg bg-red-600 text-white hover:bg-red-700 transition"
          >
            Limpar Conversa
          </button>
        </div>
      </div>

      <div className="flex flex-wrap gap-4 mb-4">
        <div>
          <label className="block text-xs font-semibold text-gray-500 mb-1">Disciplina</label>
          <select
            value={disciplina}
            onChange={(e) => setDisciplina(e.target.value)}
            className="border rounded px-3 py-2"
          >
            {DISCIPLINAS.map((d) => (
              <option key={d}>{d}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs font-semibold text-gray-500 mb-1">Tipo de Ensino</label>
          <select
            value={tipoEnsino}
            onChange={(e) => setTipoEnsino(e.target.value)}
            className="border rounded px-3 py-2"
          >
            {TIPOS_ENSINO.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs font-semibold text-gray-500 mb-1">Ano/Série</label>
          <select
            value={anoSerie}
            onChange={(e) => setAnoSerie(e.target.value)}
            className="border rounded px-3 py-2"
          >
            {ANOS_SERIES[tipoEnsino].map((a) => (
              <option key={a}>{a}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs font-semibold text-gray-500 mb-1">Modo de Atendimento</label>
          <select
            value={modoAtendimento}
            onChange={(e) => setModoAtendimento(e.target.value)}
            className="border rounded px-3 py-2"
          >
            {MODOS_ATENDIMENTO.map((m) => (
              <option key={m}>{m}</option>
            ))}
          </select>
        </div>
      </div>

      {(erro || sucesso) && (
        <div className={`p-3 rounded text-center mb-2 ${erro ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
          {erro || sucesso}
        </div>
      )}

      <div className="bg-pink-50 rounded p-4 text-base text-pink-800 mb-2">
        <strong>Dica da tutora:</strong> {DICAS[Math.floor(Math.random() * DICAS.length)]}
      </div>

      <div className="flex flex-col gap-6 overflow-y-auto flex-1 bg-white p-8 rounded-xl shadow-inner border w-full min-h-[300px]">
        {historico.map((item, index) => (
          <div key={index} className="flex flex-col gap-3">
            <div className="self-end bg-indigo-200 text-indigo-900 px-6 py-3 rounded-2xl max-w-2xl shadow text-lg">
              <strong>Você</strong> ({item.disciplina}, {item.anoSerie}, {item.tipoEnsino}): {item.pergunta}
            </div>
            <div className="self-start bg-pink-200 text-pink-900 px-6 py-3 rounded-2xl max-w-2xl shadow text-lg flex flex-col gap-2">
              <div>
                <strong>Professora IAula:</strong> {item.resposta}
              </div>
              <div className="flex justify-end">
                <button
                  onClick={() => copiarResposta(item.resposta)}
                  className="text-xs bg-pink-300 hover:bg-pink-400 text-pink-900 font-bold py-1 px-4 rounded-lg transition"
                >
                  Copiar
                </button>
              </div>
            </div>
          </div>
        ))}
        {carregando && (
          <div className="self-start bg-gray-200 text-gray-700 px-6 py-3 rounded-lg max-w-2xl shadow animate-pulse text-lg">
            Professora IAula está pensando...
          </div>
        )}
        <div ref={endRef} />
      </div>

      <div className="flex flex-col sm:flex-row gap-6 mt-4 w-full">
        <textarea
          className="flex-1 h-32 p-5 text-gray-900 rounded-lg border border-gray-300 shadow focus:ring-pink-500 focus:border-pink-500 text-lg"
          placeholder="Digite sua dúvida para a tutora aqui..."
          value={pergunta}
          onChange={(e) => setPergunta(e.target.value)}
          disabled={carregando}
        />
        <div className="flex flex-col gap-3 min-w-[200px]">
          <button
            onClick={enviarPergunta}
            disabled={carregando || !pergunta.trim()}
            className="h-14 px-8 py-3 rounded-lg bg-pink-600 text-white font-semibold text-lg hover:bg-pink-700 transition disabled:opacity-50 self-center"
          >
            {carregando ? 'Pensando...' : 'Perguntar à Tutora'}
          </button>
          <button
            onClick={sugestaoPergunta}
            disabled={carregando}
            className="h-14 px-8 py-3 rounded-lg bg-yellow-400 text-gray-900 font-semibold text-lg hover:bg-yellow-300 transition"
          >
            🎲 Surpreenda-me!
          </button>
        </div>
      </div>

      <footer className="mt-8 text-center text-xs text-gray-400">
        Professora IAula — Tutora virtual. Sempre pronta para ajudar nos seus estudos!
      </footer>
    </div>
  )
}