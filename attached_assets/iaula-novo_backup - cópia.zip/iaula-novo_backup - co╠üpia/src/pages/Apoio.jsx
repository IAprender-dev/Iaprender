import { useState, useEffect, useRef } from 'react'
import axios from 'axios'
import { jsPDF } from 'jspdf'
import { gapi } from 'gapi-script'

const CLIENT_ID = '709799557322-u8b85k6j9pbkopap4ngn63an2853ejt2.apps.googleusercontent.com'
const SCOPE = 'https://www.googleapis.com/auth/drive.file'

// Opções visuais de IA de texto (todas usam sua API por baixo)
const MODELOS_IA_TEXTO = [
  { nome: 'ChatGPT', valor: 'chatgpt', descricao: 'OpenAI, referência mundial', cor: 'bg-green-600', icone: '💬' },
  { nome: 'Gemini', valor: 'gemini', descricao: 'Google, integração Bard', cor: 'bg-yellow-400', icone: '✨' },
  { nome: 'Claude', valor: 'claude', descricao: 'Anthropic, ética e contexto', cor: 'bg-blue-500', icone: '🧠' },
  { nome: 'Llama', valor: 'llama', descricao: 'Meta, open source', cor: 'bg-purple-600', icone: '🦙' },
  { nome: 'Copilot', valor: 'copilot', descricao: 'Microsoft, foco em produtividade', cor: 'bg-blue-800', icone: '🤖' },
  { nome: 'Perplexity', valor: 'perplexity', descricao: 'Busca e respostas rápidas', cor: 'bg-pink-500', icone: '🔍' },
  { nome: 'Mistral', valor: 'mistral', descricao: 'Alta performance open source', cor: 'bg-orange-500', icone: '🌬️' },
  // OpenAI (usada de fato) sempre por último e destacada
  { nome: 'OpenAI (usada aqui)', valor: 'openai', descricao: 'GPT-3.5 Turbo', cor: 'bg-indigo-600', icone: '🚀', destaque: true },
]

const DICAS = [
  "Seja específico na sua dúvida para respostas melhores.",
  "Pergunte sobre conceitos, exemplos ou resumos.",
  "Peça explicações simples, como para uma criança.",
  "Use o botão Surpreenda-me para ideias de perguntas!",
  "Aproveite para revisar conteúdos antes de provas.",
]

const SUGESTOES_PERGUNTA = [
  "Explique o ciclo da água de forma simples.",
  "O que é fotossíntese?",
  "Como funciona o sistema solar?",
  "Resuma a Revolução Francesa.",
  "Quais são as fases da Lua?",
  "Dê um exemplo de multiplicação.",
  "Como se forma um arco-íris?",
  "O que é biodiversidade?",
  "Qual a diferença entre massa e peso?",
]

function AjudaModal({ open, onClose }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black bg-opacity-40">
      <div className="bg-white rounded-lg p-6 max-w-md w-full shadow-lg relative">
        <button
          aria-label="Fechar ajuda"
          onClick={onClose}
          className="absolute top-2 right-2 text-gray-400 hover:text-gray-700 text-xl"
        >×</button>
        <h2 className="text-xl font-bold mb-2">Ajuda Rápida</h2>
        <ul className="list-disc pl-5 space-y-2 text-sm">
          <li>Faça perguntas sobre qualquer conteúdo escolar.</li>
          <li>Use o botão <b>Surpreenda-me</b> para sugestões de perguntas.</li>
          <li>Copie respostas para usar em resumos ou estudos.</li>
          <li>Salve ou envie a conversa para o Google Drive.</li>
          <li>Limpe o histórico quando quiser começar uma nova conversa.</li>
        </ul>
      </div>
    </div>
  );
}

export default function Apoio() {
  const [modeloIA, setModeloIA] = useState(MODELOS_IA_TEXTO[0].valor)
  const [pergunta, setPergunta] = useState('')
  const [historico, setHistorico] = useState([])
  const [carregando, setCarregando] = useState(false)
  const [googleSignedIn, setGoogleSignedIn] = useState(false)
  const [erro, setErro] = useState('')
  const [ajudaAberta, setAjudaAberta] = useState(false)
  const [sucesso, setSucesso] = useState('')
  const endRef = useRef(null)

  useEffect(() => {
    const historicoSalvo = localStorage.getItem('apoioHistorico')
    if (historicoSalvo) setHistorico(JSON.parse(historicoSalvo))
    gapi.load('client:auth2', initClient)
  }, [])

  useEffect(() => {
    if (endRef.current) {
      endRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [historico])

  const initClient = () => {
    gapi.client.init({
      clientId: CLIENT_ID,
      scope: SCOPE,
    }).then(() => {
      const auth = gapi.auth2.getAuthInstance()
      setGoogleSignedIn(auth.isSignedIn.get())
      auth.isSignedIn.listen(setGoogleSignedIn)
    })
  }

  const handleLoginGoogle = () => {
    const auth = gapi.auth2.getAuthInstance()
    auth.signIn()
  }

  const enviarPergunta = async () => {
    if (!pergunta.trim()) return
    setErro('')
    setSucesso('')
    const novaPergunta = pergunta.trim()
    setPergunta('')
    setCarregando(true)

    try {
      const apiKey = import.meta.env.VITE_OPENAI_API_KEY

      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-3.5-turbo',
          messages: [
            { role: 'system', content: 'Você é um assistente educacional chamado IAula que responde dúvidas de forma clara e simples.' },
            { role: 'user', content: novaPergunta }
          ],
          temperature: 0.7,
        },
        {
          headers: {
            Authorization: `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
          },
        }
      )

      const respostaIA = response.data.choices[0].message.content
      const novoItem = { pergunta: novaPergunta, resposta: respostaIA, modeloIA }
      const novoHistorico = [...historico, novoItem]
      setHistorico(novoHistorico)
      localStorage.setItem('apoioHistorico', JSON.stringify(novoHistorico))
      setSucesso('Resposta recebida!')

    } catch (error) {
      setErro('Erro ao buscar resposta da IAula. Tente novamente.')
      const novoItemErro = { pergunta: novaPergunta, resposta: 'Erro ao buscar resposta da IAula. Tente novamente.', modeloIA }
      const novoHistorico = [...historico, novoItemErro]
      setHistorico(novoHistorico)
      localStorage.setItem('apoioHistorico', JSON.stringify(novoHistorico))
    } finally {
      setCarregando(false)
      setTimeout(() => setSucesso(''), 2000)
    }
  }

  const limparHistorico = () => {
    if (confirm('Tem certeza que deseja limpar a conversa?')) {
      setHistorico([])
      localStorage.removeItem('apoioHistorico')
    }
  }

  const baixarConversaPdf = () => {
    if (historico.length === 0) {
      setErro('Nenhuma conversa para baixar.')
      return
    }
    const doc = new jsPDF()
    let y = 10
    historico.forEach((item) => {
      doc.setFontSize(12)
      doc.text(`Você: ${item.pergunta}`, 10, y)
      y += 10
      doc.text(`IAula: ${item.resposta}`, 10, y)
      y += 20
      if (y > 270) {
        doc.addPage()
        y = 10
      }
    })
    doc.save('conversa-iaula.pdf')
    setSucesso('PDF baixado com sucesso!')
    setTimeout(() => setSucesso(''), 2000)
  }

  const copiarResposta = (resposta) => {
    navigator.clipboard.writeText(resposta)
    setSucesso('Resposta copiada para a área de transferência!')
    setTimeout(() => setSucesso(''), 2000)
  }

  const uploadPdfParaGoogleDrive = async () => {
    if (historico.length === 0) {
      setErro('Nenhuma conversa para enviar.')
      return
    }

    const doc = new jsPDF()
    let y = 10
    historico.forEach((item) => {
      doc.setFontSize(12)
      doc.text(`Você: ${item.pergunta}`, 10, y)
      y += 10
      doc.text(`IAula: ${item.resposta}`, 10, y)
      y += 20
      if (y > 270) {
        doc.addPage()
        y = 10
      }
    })

    const pdfBlob = doc.output('blob')
    const accessToken = gapi.auth2.getAuthInstance().currentUser.get().getAuthResponse().access_token

    try {
      const searchResponse = await fetch('https://www.googleapis.com/drive/v3/files?q=name="IAula"+and+mimeType="application/vnd.google-apps.folder"+and+trashed=false', {
        headers: new Headers({ Authorization: `Bearer ${accessToken}` }),
      })

      const searchData = await searchResponse.json()
      let folderId = null

      if (searchData.files && searchData.files.length > 0) {
        folderId = searchData.files[0].id
      } else {
        const folderMetadata = {
          name: 'IAula',
          mimeType: 'application/vnd.google-apps.folder',
        }

        const folderResponse = await fetch('https://www.googleapis.com/drive/v3/files', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(folderMetadata),
        })

        const folderData = await folderResponse.json()
        folderId = folderData.id
      }

      const metadata = {
        name: 'conversa-iaula.pdf',
        parents: [folderId],
        mimeType: 'application/pdf',
      }

      const form = new FormData()
      form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }))
      form.append('file', pdfBlob)

      const uploadResponse = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
        method: 'POST',
        headers: new Headers({ Authorization: `Bearer ${accessToken}` }),
        body: form,
      })

      if (uploadResponse.ok) {
        setSucesso('Conversa salva como PDF na pasta IAula no Google Drive!')
      } else {
        setErro('Erro ao enviar o PDF para o Drive.')
      }

    } catch (error) {
      setErro('Erro inesperado ao salvar no Google Drive.')
    }
    setTimeout(() => { setErro(''); setSucesso('') }, 2000)
  }

  const sugestaoPergunta = () => {
    const aleatorio = SUGESTOES_PERGUNTA[Math.floor(Math.random() * SUGESTOES_PERGUNTA.length)]
    setPergunta(aleatorio)
  }

  return (
    <div className="flex flex-col h-full p-6 sm:p-10 gap-6 max-w-6xl mx-auto w-full">
      <AjudaModal open={ajudaAberta} onClose={() => setAjudaAberta(false)} />

      {/* Opções de IA de texto */}
      <div className="flex flex-wrap gap-4 mb-4" role="radiogroup" aria-label="Modelos de IA de texto">
        {MODELOS_IA_TEXTO.map((ia) => (
          <button
            key={ia.valor}
            aria-label={`Selecionar modelo ${ia.nome}`}
            onClick={() => setModeloIA(ia.valor)}
            className={`flex flex-col items-center px-4 py-3 rounded-lg border-2 shadow transition font-semibold
              ${modeloIA === ia.valor
                ? `${ia.cor} text-white border-indigo-700 scale-105`
                : ia.destaque
                  ? 'bg-white text-indigo-700 border-indigo-400 ring-2 ring-indigo-300'
                  : 'bg-white text-gray-800 border-gray-200 hover:bg-gray-50'}
              ${ia.destaque ? 'rounded-full' : ''}
            `}
            style={{ minWidth: 120 }}
          >
            <span className="text-2xl mb-1">{ia.icone}</span>
            <span>{ia.nome}</span>
            <span className="text-xs font-normal">{ia.descricao}</span>
            {ia.destaque && <span className="text-xs mt-1 font-bold text-indigo-700">Usada aqui</span>}
          </button>
        ))}
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-2">
        <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
          <span>🤖 Apoio aos Estudos (IAula)</span>
          <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-1 rounded">Beta</span>
          <button
            aria-label="Abrir ajuda"
            onClick={() => setAjudaAberta(true)}
            className="px-2 py-1 bg-indigo-50 text-indigo-700 rounded hover:bg-indigo-100 text-xs font-semibold"
          >
            Ajuda
          </button>
        </h1>
        <div className="flex flex-wrap gap-3">
          {!googleSignedIn && (
            <button
              onClick={handleLoginGoogle}
              className="px-5 py-3 text-base rounded-lg bg-yellow-500 text-white hover:bg-yellow-600 transition"
            >
              Conectar Google Drive
            </button>
          )}
          {googleSignedIn && (
            <button
              onClick={uploadPdfParaGoogleDrive}
              className="px-5 py-3 text-base rounded-lg bg-green-600 text-white hover:bg-green-700 transition"
            >
              Salvar PDF no Drive
            </button>
          )}
          <button
            onClick={baixarConversaPdf}
            className="px-5 py-3 text-base rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition"
          >
            Baixar PDF
          </button>
          <button
            onClick={limparHistorico}
            className="px-5 py-3 text-base rounded-lg bg-red-600 text-white hover:bg-red-700 transition"
          >
            Limpar Conversa
          </button>
        </div>
      </div>

      {/* Feedback visual */}
      {(erro || sucesso) && (
        <div className={`p-3 rounded text-center mb-2 ${erro ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
          {erro || sucesso}
        </div>
      )}

      {/* Dica rápida */}
      <div className="bg-indigo-50 rounded p-4 text-base text-indigo-800 mb-2">
        <strong>Dica:</strong> {DICAS[Math.floor(Math.random() * DICAS.length)]}
      </div>

      {/* Histórico */}
      <div className="flex flex-col gap-6 overflow-y-auto flex-1 bg-white p-8 rounded-xl shadow-inner border w-full min-h-[300px]">
        {historico.map((item, index) => (
          <div key={index} className="flex flex-col gap-3">
            <div className="self-end bg-indigo-200 text-indigo-900 px-6 py-3 rounded-2xl max-w-2xl shadow text-lg">
              <strong>Você:</strong> {item.pergunta}
            </div>
            <div className="self-start bg-green-200 text-green-900 px-6 py-3 rounded-2xl max-w-2xl shadow text-lg flex flex-col gap-2">
              <div>
                <strong>IAula:</strong> {item.resposta}
              </div>
              <div className="flex justify-end">
                <button
                  onClick={() => copiarResposta(item.resposta)}
                  className="text-xs bg-green-300 hover:bg-green-400 text-green-900 font-bold py-1 px-4 rounded-lg transition"
                >
                  Copiar
                </button>
              </div>
            </div>
          </div>
        ))}
        {carregando && (
          <div className="self-start bg-gray-200 text-gray-700 px-6 py-3 rounded-lg max-w-2xl shadow animate-pulse text-lg">
            IAula está pensando...
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Pergunta e Surpreenda-me */}
      <div className="flex flex-col sm:flex-row gap-6 mt-4 w-full">
        <textarea
          className="flex-1 h-32 p-5 text-gray-900 rounded-lg border border-gray-300 shadow focus:ring-indigo-500 focus:border-indigo-500 text-lg"
          placeholder="Digite sua dúvida aqui..."
          value={pergunta}
          onChange={(e) => setPergunta(e.target.value)}
          disabled={carregando}
        />
        <div className="flex flex-col gap-3 min-w-[200px]">
          <button
            onClick={enviarPergunta}
            disabled={carregando || !pergunta.trim()}
            className="h-14 px-8 py-3 rounded-lg bg-indigo-600 text-white font-semibold text-lg hover:bg-indigo-700 transition disabled:opacity-50 self-center"
          >
            {carregando ? 'Pensando...' : 'Perguntar IAula'}
          </button>
          <button
            onClick={sugestaoPergunta}
            disabled={carregando}
            className="h-14 px-8 py-3 rounded-lg bg-yellow-400 text-gray-900 font-semibold text-lg hover:bg-yellow-300 transition"
            title="Gerar uma sugestão de pergunta educativa"
          >
            🎲 Surpreenda-me!
          </button>
        </div>
      </div>

      <footer className="mt-8 text-center text-xs text-gray-400">
        IAula — Assistente educacional. Para uso escolar.
      </footer>
    </div>
  )
}