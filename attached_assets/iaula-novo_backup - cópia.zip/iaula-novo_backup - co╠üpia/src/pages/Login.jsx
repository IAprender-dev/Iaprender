import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [usuario, setUsuario] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    // Exemplo simples: usuário "admin" e senha "1234"
    if (usuario === "admin" && senha === "1234") {
      localStorage.setItem("auth", "true");
      navigate("/");
    } else {
      setErro("Usuário ou senha inválidos");
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50">
      <form
        onSubmit={handleLogin}
        className="bg-white p-8 rounded shadow-md w-full max-w-sm flex flex-col gap-4"
      >
        <h1 className="text-2xl font-bold text-indigo-600 mb-4 text-center">
          IAula - Login
        </h1>
        {erro && (
          <div className="bg-red-100 text-red-700 p-2 rounded text-center">
            {erro}
          </div>
        )}
        <input
          type="text"
          placeholder="Usuário"
          className="border p-3 rounded"
          value={usuario}
          onChange={(e) => setUsuario(e.target.value)}
          autoFocus
        />
        <input
          type="password"
          placeholder="Senha"
          className="border p-3 rounded"
          value={senha}
          onChange={(e) => setSenha(e.target.value)}
        />
        <button
          type="submit"
          className="bg-indigo-600 text-white rounded p-3 font-bold hover:bg-indigo-700"
        >
          Entrar
        </button>
        <div className="text-xs text-gray-400 text-center mt-2">
          Usuário: <b>admin</b> | Senha: <b>1234</b>
        </div>
      </form>
    </div>
  );
}