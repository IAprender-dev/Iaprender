import { useState, useEffect } from "react";
import { jsPDF } from "jspdf";
import axios from "axios";

const DISCIPLINAS = [
  "Matemática", "Português", "Ciências", "História", "Geografia", "Física", "Química", "Biologia"
];

const TIPOS_EXERCICIOS = [
  "Objetivas (Múltipla Escolha)", "Discursivas", "Desafios", "Lúdicas (Criativas)"
];

const NIVEIS_DIFICULDADE = ["Fácil", "Intermediário", "Avançado"];

const ANOS_ESCOLARES = [
  "1º Ano Fundamental", "2º Ano Fundamental", "3º Ano Fundamental", "4º Ano Fundamental",
  "5º Ano Fundamental", "6º Ano Fundamental", "7º Ano Fundamental", "8º Ano Fundamental",
  "9º Ano Fundamental", "1ª Série Médio", "2ª Série Médio", "3ª Série Médio"
];

const SUGESTOES_TEMAS = [
  "Equações do 1º Grau", "Sistema Solar", "Segunda Guerra Mundial",
  "Fotossíntese", "O Ciclo da Água", "Geometria Espacial"
];

const DICAS = [
  "Escolha um tema claro para atividades mais precisas.",
  "Combine conteúdos fáceis com desafios para estimular os alunos.",
  "Experimente usar 'Lúdicas' para momentos criativos.",
  "Use o ano escolar para personalizar as atividades de acordo com o nível dos estudantes."
];

export default function GeradorAtividades() {
  // Estados principais
  const [tema, setTema] = useState("");
  const [disciplina, setDisciplina] = useState(DISCIPLINAS[0]);
  const [anoEscolar, setAnoEscolar] = useState(ANOS_ESCOLARES[0]);
  const [tipoExercicio, setTipoExercicio] = useState(TIPOS_EXERCICIOS[0]);
  const [nivelDificuldade, setNivelDificuldade] = useState(NIVEIS_DIFICULDADE[0]);

  const [exerciciosGerados, setExerciciosGerados] = useState(""); // Armazenar os exercícios gerados
  const [historico, setHistorico] = useState([]); // Histórico de atividades geradas

  // Modal de ajuda e visualização
  const [modalAtividade, setModalAtividade] = useState(null);
  const [openModalAjuda, setOpenModalAjuda] = useState(false);

  const [loading, setLoading] = useState(false);
  const [erro, setErro] = useState("");
  const [sucesso, setSucesso] = useState("");

  useEffect(() => {
    const historicoSalvo = localStorage.getItem("atividadesHistorico");
    if (historicoSalvo) setHistorico(JSON.parse(historicoSalvo));
  }, []);

  const salvarHistorico = (atividade) => {
    const novoHistorico = [atividade, ...historico];
    setHistorico(novoHistorico);
    localStorage.setItem("atividadesHistorico", JSON.stringify(novoHistorico));
  };

  const gerarAtividadesIA = async () => {
    if (!tema.trim()) {
      setErro("Digite um tema para gerar atividades!");
      setTimeout(() => setErro(""), 2000);
      return;
    }

    setErro("");
    setSucesso("");
    setLoading(true);
    const prompt = `
Você é um professor altamente qualificado na disciplina de ${disciplina}, especialista em educação básica e média.
Sua tarefa é criar uma lista de no mínimo 10 exercícios com base nas seguintes especificações:

- Tema: ${tema}
- Ano Escolar: ${anoEscolar}
- Tipo de Exercício: ${tipoExercicio} (adaptar a estrutura conforme tipo)
- Nível de Dificuldade: ${nivelDificuldade}

Diretrizes:
- Para questões objetivas, forneça 4 alternativas e destaque a correta de forma clara.
- Para questões discursivas ou desafios, incentive respostas completas e reflexivas.
- Varie a complexidade das questões conforme o nível solicitado.
- Numere os exercícios para facilitar a leitura.
- Use linguagem adequada à faixa etária do ano escolar selecionado.
- Inclua instruções claras e, quando possível, adicione exemplos.
- Estimule o pensamento crítico, a criatividade e a autonomia do estudante.

Capriche na elaboração para que as atividades sejam motivadoras e didáticas!
`;
    try {
      const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
      const response = await axios.post(
        "https://api.openai.com/v1/chat/completions",
        {
          model: "gpt-3.5-turbo",
          messages: [{ role: "user", content: prompt }],
          temperature: 0.7
        },
        {
          headers: {
            Authorization: `Bearer ${apiKey}`,
            "Content-Type": "application/json"
          }
        }
      );

      const atividades = response.data.choices[0].message.content;
      setExerciciosGerados(atividades);

      salvarHistorico({
        tema,
        disciplina,
        anoEscolar,
        tipo: tipoExercicio,
        dificuldade: nivelDificuldade,
        atividades,
        data: new Date().toISOString()
      });

      setSucesso("Atividades geradas com sucesso!");
      setTimeout(() => setSucesso(""), 3000);
    } catch (error) {
      setErro("Erro ao gerar as atividades. Verifique sua chave de API.");
    } finally {
      setLoading(false);
    }
  };

  const baixarPdfAtividades = (texto, nomeArquivo = "atividades-geradas.pdf") => {
    const doc = new jsPDF();
    const margin = 10;
    const lineHeight = 10;
    const maxLineWidth = 180;
    let y = margin;
    const lines = doc.splitTextToSize(texto, maxLineWidth);

    lines.forEach((line) => {
      if (y > 280) {
        doc.addPage();
        y = margin;
      }
      doc.text(line, margin, y);
      y += lineHeight;
    });

    doc.save(nomeArquivo);
    setSucesso("PDF baixado com sucesso!");
    setTimeout(() => setSucesso(""), 2000);
  };

  const limparHistorico = () => {
    if (window.confirm("Tem certeza que deseja limpar todo o histórico?")) {
      setHistorico([]);
      localStorage.removeItem("atividadesHistorico");
    }
  };

  const sugerirTema = () => {
    const aleatorio = SUGESTOES_TEMAS[Math.floor(Math.random() * SUGESTOES_TEMAS.length)];
    setTema(aleatorio);
  };

  return (
    <div className="flex flex-col max-w-5xl mx-auto p-8 gap-8">
      {/* Cabeçalho */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Gerador de Atividades com IA</h1>
        <button
          onClick={() => setOpenModalAjuda(true)}
          className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
        >
          Ajuda
        </button>
      </div>

      {/* Dicas */}
      <div className="bg-indigo-100 text-indigo-800 p-4 rounded-lg">
        <strong>Dica:</strong> {DICAS[Math.floor(Math.random() * DICAS.length)]}
      </div>

      {/* Feedback */}
      {erro && <div className="text-red-600 bg-red-100 p-3 rounded">{erro}</div>}
      {sucesso && <div className="text-green-600 bg-green-100 p-3 rounded">{sucesso}</div>}

      {/* Formulário */}
      <div className="grid md:grid-cols-2 gap-6 bg-white p-6 rounded shadow">
        <div className="flex flex-col gap-4">
          <select
            className="border p-3 rounded"
            value={disciplina}
            onChange={(e) => setDisciplina(e.target.value)}
          >
            {DISCIPLINAS.map((d) => (
              <option key={d}>{d}</option>
            ))}
          </select>
          <select
            className="border p-3 rounded"
            value={anoEscolar}
            onChange={(e) => setAnoEscolar(e.target.value)}
          >
            {ANOS_ESCOLARES.map((ano) => (
              <option key={ano}>{ano}</option>
            ))}
          </select>
          <select
            className="border p-3 rounded"
            value={tipoExercicio}
            onChange={(e) => setTipoExercicio(e.target.value)}
          >
            {TIPOS_EXERCICIOS.map((tipo) => (
              <option key={tipo}>{tipo}</option>
            ))}
          </select>
          <select
            className="border p-3 rounded"
            value={nivelDificuldade}
            onChange={(e) => setNivelDificuldade(e.target.value)}
          >
            {NIVEIS_DIFICULDADE.map((nivel) => (
              <option key={nivel}>{nivel}</option>
            ))}
          </select>
        </div>

        <div className="flex flex-col gap-4">
          <textarea
            className="border p-3 rounded h-32"
            placeholder="Digite o tema ou conteúdo das atividades"
            value={tema}
            onChange={(e) => setTema(e.target.value)}
          ></textarea>
          <button
            onClick={sugerirTema}
            className="px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-400"
          >
            🎲 Surpreenda-me!
          </button>
        </div>
      </div>

      <button
        onClick={gerarAtividadesIA}
        disabled={loading}
        className="px-6 py-3 bg-indigo-600 text-white rounded hover:bg-indigo-700"
      >
        {loading ? "Gerando..." : "Gerar Atividades"}
      </button>

      {/* Exibição das Atividades Geradas */}
      {exerciciosGerados && (
        <div className="bg-white p-6 shadow rounded">
          <h2 className="text-xl font-bold mb-4">Atividades Geradas</h2>
          <div className="bg-gray-100 p-4 rounded text-gray-800 whitespace-pre-wrap max-h-64 overflow-y-auto">
            {exerciciosGerados}
          </div>
          <button
            onClick={() => baixarPdfAtividades(exerciciosGerados)}
            className="mt-4 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
          >
            Baixar PDF
          </button>
        </div>
      )}

      {/* Histórico */}
      {historico.length > 0 && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">📜 Histórico de Atividades</h2>
            <button
              onClick={limparHistorico}
              className="text-red-700 px-4 py-2 bg-red-100 rounded-lg hover:bg-red-200"
            >
              Limpar Histórico
            </button>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            {historico.map((item, index) => (
              <div key={index} className="bg-white shadow p-4 rounded">
                <h3 className="text-indigo-600 font-bold">{item.tema}</h3>
                <p className="text-gray-600">
                  {item.anoEscolar} • {item.disciplina}
                </p>
                <button
                  onClick={() => setModalAtividade(item)}
                  className="text-blue-600 mt-2 hover:underline"
                >
                  Visualizar
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal de Ajuda */}
      {openModalAjuda && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-10">
          <div className="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
            <h2 className="text-2xl font-bold mb-4">Como usar o Gerador?</h2>
            <p>
              Preencha o formulário com as configurações desejadas, insira um tema ou clique em "Surpreenda-me" para gerar um tema aleatório.
              Clique no botão "Gerar Atividades" para criar a lista.
            </p>
            <button
              onClick={() => setOpenModalAjuda(false)}
              className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
            >
              Fechar
            </button>
          </div>
        </div>
      )}

      {/* Modal de Visualização do Histórico */}
      {modalAtividade && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-20">
          <div className="bg-white rounded p-6 max-w-2xl w-full max-h-96 overflow-y-auto shadow-lg">
            <h3 className="text-xl font-bold">{modalAtividade.tema}</h3>
            <p className="text-gray-600">
              {modalAtividade.anoEscolar} • {modalAtividade.disciplina}
            </p>
            <div className="mt-4 bg-gray-100 p-4 rounded text-gray-800 whitespace-pre-wrap">
              {modalAtividade.atividades}
            </div>
            <div className="flex justify-between mt-4">
              <button
                onClick={() => baixarPdfAtividades(modalAtividade.atividades, `historico-${modalAtividade.tema}.pdf`)}
                className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
              >
                Baixar PDF
              </button>
              <button
                onClick={() => setModalAtividade(null)}
                className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}