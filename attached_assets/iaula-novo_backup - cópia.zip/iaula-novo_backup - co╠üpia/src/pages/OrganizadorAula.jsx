import { useState, useEffect } from "react";
import { jsPDF } from "jspdf";
import axios from "axios";
import { Calendar, Lightbulb, Download, HelpCircle } from "lucide-react";

const DISCIPLINAS = [
  "Matemática", "Português", "Ciências", "História", "Geografia", "Física", "Química", "Biologia"
];
const ANOS_ESCOLARES = [
  "1º Ano Fundamental", "2º Ano Fundamental", "3º Ano Fundamental", "4º Ano Fundamental",
  "5º Ano Fundamental", "6º Ano Fundamental", "7º Ano Fundamental", "8º Ano Fundamental",
  "9º Ano Fundamental", "1ª Série Médio", "2ª Série Médio", "3ª Série Médio"
];
const PERIODOS = ["Semanal", "Quinzenal", "Mensal"];
const DICAS = [
  "Inclua revisões a cada 2 ou 3 temas para consolidar o aprendizado.",
  "Diversifique as atividades: intercale teoria, prática e avaliações.",
  "Reserve tempo para debates, projetos e dinâmicas.",
  "Use recursos digitais para enriquecer as aulas.",
  "Adapte o ritmo conforme o perfil da turma."
];
const SUGESTOES_TEMAS = [
  "Frações", "Revolução Industrial", "Fotossíntese", "Leitura e Interpretação de Texto",
  "Geometria Espacial", "Ciclo da Água", "Energia e Trabalho", "Gramática: Pontuação"
];

export default function OrganizadorAula() {
  const [disciplina, setDisciplina] = useState(DISCIPLINAS[0]);
  const [anoEscolar, setAnoEscolar] = useState(ANOS_ESCOLARES[0]);
  const [periodo, setPeriodo] = useState(PERIODOS[0]);
  const [dataInicio, setDataInicio] = useState("");
  const [dataFim, setDataFim] = useState("");
  const [temas, setTemas] = useState([]);
  const [temaInput, setTemaInput] = useState("");
  const [cargaSemanal, setCargaSemanal] = useState(4);
  const [feriados, setFeriados] = useState([]);
  const [cronogramaGerado, setCronogramaGerado] = useState("");
  const [historico, setHistorico] = useState([]);
  const [loading, setLoading] = useState(false);
  const [erro, setErro] = useState("");
  const [sucesso, setSucesso] = useState("");
  const [openAjuda, setOpenAjuda] = useState(false);
  const [modalCronograma, setModalCronograma] = useState(null);

  useEffect(() => {
    const historicoSalvo = localStorage.getItem("cronogramasHistorico");
    if (historicoSalvo) setHistorico(JSON.parse(historicoSalvo));
  }, []);

  const salvarHistorico = (cronograma) => {
    const novoHistorico = [cronograma, ...historico];
    setHistorico(novoHistorico);
    localStorage.setItem("cronogramasHistorico", JSON.stringify(novoHistorico));
  };

  const adicionarTema = () => {
    if (temaInput.trim() && !temas.includes(temaInput.trim())) {
      setTemas([...temas, temaInput.trim()]);
      setTemaInput("");
    }
  };

  const removerTema = (tema) => setTemas(temas.filter(t => t !== tema));

  const sugerirTema = () => {
    const aleatorio = SUGESTOES_TEMAS[Math.floor(Math.random() * SUGESTOES_TEMAS.length)];
    setTemaInput(aleatorio);
  };

  const adicionarFeriado = (data) => {
    if (data && !feriados.includes(data)) setFeriados([...feriados, data]);
  };

  const removerFeriado = (data) => setFeriados(feriados.filter(f => f !== data));

  const gerarCronogramaIA = async () => {
    // Inclui automaticamente o tema digitado, se houver
    let temasAtualizados = temas;
    if (temaInput.trim() && !temas.includes(temaInput.trim())) {
      temasAtualizados = [...temas, temaInput.trim()];
      setTemas(temasAtualizados);
      setTemaInput("");
    }

    if (!dataInicio || !dataFim || temasAtualizados.length === 0) {
      setErro("Preencha datas e temas para gerar o cronograma!");
      setTimeout(() => setErro(""), 2000);
      return;
    }

    setErro("");
    setSucesso("");
    setLoading(true);

    const prompt = `
Você é um coordenador pedagógico especialista em ${disciplina} para o ${anoEscolar}.
Crie um CRONOGRAMA DE AULAS ${periodo.toUpperCase()} para o período de ${dataInicio} até ${dataFim}.

- Temas a abordar: ${temasAtualizados.join(", ")}
- Carga horária semanal: ${cargaSemanal} aulas
- Feriados/dias sem aula: ${feriados.length > 0 ? feriados.join(", ") : "nenhum"}
- Distribua os temas de forma equilibrada, considerando revisões e avaliações.
- Sugira para cada semana/módulo: atividades práticas, recursos didáticos (vídeo, leitura, experimento), avaliações e dicas pedagógicas.
- Apresente o cronograma em formato de tabela, com colunas: Semana/Data, Tema, Atividades, Recursos, Avaliação, Observações.
- Adicione sugestões criativas e dinâmicas para engajar os alunos.
- Ao final, destaque dicas para o professor otimizar o planejamento.

Capriche na organização, criatividade e clareza!
`;

    try {
      const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
      const response = await axios.post(
        "https://api.openai.com/v1/chat/completions",
        {
          model: "gpt-3.5-turbo",
          messages: [{ role: "user", content: prompt }],
          temperature: 0.7
        },
        {
          headers: {
            Authorization: `Bearer ${apiKey}`,
            "Content-Type": "application/json"
          }
        }
      );

      const cronograma = response.data.choices[0].message.content;
      setCronogramaGerado(cronograma);

      salvarHistorico({
        disciplina,
        anoEscolar,
        periodo,
        dataInicio,
        dataFim,
        temas: temasAtualizados,
        cargaSemanal,
        feriados,
        cronograma,
        data: new Date().toISOString()
      });

      setSucesso("Cronograma gerado com sucesso!");
      setTimeout(() => setSucesso(""), 3000);
    } catch (error) {
      setErro("Erro ao gerar o cronograma. Verifique sua chave de API.");
    } finally {
      setLoading(false);
    }
  };

  const baixarPdf = (texto, nomeArquivo = "cronograma-aula.pdf") => {
    const doc = new jsPDF();
    const margin = 10;
    const lineHeight = 10;
    const maxLineWidth = 180;
    let y = margin;
    const lines = doc.splitTextToSize(texto, maxLineWidth);

    lines.forEach((line) => {
      if (y > 280) {
        doc.addPage();
        y = margin;
      }
      doc.text(line, margin, y);
      y += lineHeight;
    });

    doc.save(nomeArquivo);
    setSucesso("PDF baixado com sucesso!");
    setTimeout(() => setSucesso(""), 2000);
  };

  const limparHistorico = () => {
    if (window.confirm("Tem certeza que deseja limpar todo o histórico?")) {
      setHistorico([]);
      localStorage.removeItem("cronogramasHistorico");
    }
  };

  return (
    <div className="flex flex-col max-w-5xl mx-auto p-8 gap-8">
      {/* Cabeçalho */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Calendar size={28} /> Organizador de Aula IA
        </h1>
        <button
          onClick={() => setOpenAjuda(true)}
          className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center gap-2"
        >
          <HelpCircle size={18} /> Ajuda
        </button>
      </div>

      {/* Dicas */}
      <div className="bg-indigo-100 text-indigo-800 p-4 rounded-lg flex items-center gap-2">
        <Lightbulb size={18} /> <strong>Dica:</strong> {DICAS[Math.floor(Math.random() * DICAS.length)]}
      </div>

      {/* Feedback */}
      {erro && <div className="text-red-600 bg-red-100 p-3 rounded">{erro}</div>}
      {sucesso && <div className="text-green-600 bg-green-100 p-3 rounded">{sucesso}</div>}

      {/* Formulário */}
      <div className="grid md:grid-cols-2 gap-6 bg-white p-6 rounded shadow">
        <div className="flex flex-col gap-4">
          <select
            className="border p-3 rounded"
            value={disciplina}
            onChange={(e) => setDisciplina(e.target.value)}
          >
            {DISCIPLINAS.map((d) => (
              <option key={d}>{d}</option>
            ))}
          </select>
          <select
            className="border p-3 rounded"
            value={anoEscolar}
            onChange={(e) => setAnoEscolar(e.target.value)}
          >
            {ANOS_ESCOLARES.map((ano) => (
              <option key={ano}>{ano}</option>
            ))}
          </select>
          <select
            className="border p-3 rounded"
            value={periodo}
            onChange={(e) => setPeriodo(e.target.value)}
          >
            {PERIODOS.map((p) => (
              <option key={p}>{p}</option>
            ))}
          </select>
          <div className="flex gap-2">
            <input
              type="date"
              className="border p-3 rounded w-full"
              value={dataInicio}
              onChange={(e) => setDataInicio(e.target.value)}
            />
            <input
              type="date"
              className="border p-3 rounded w-full"
              value={dataFim}
              onChange={(e) => setDataFim(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium">Carga horária semanal (aulas):</label>
            <input
              type="number"
              min={1}
              max={10}
              className="border p-2 rounded w-24"
              value={cargaSemanal}
              onChange={(e) => setCargaSemanal(Number(e.target.value))}
            />
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <label className="font-medium">Temas/Conteúdos:</label>
          <div className="flex gap-2">
            <input
              className="border p-3 rounded flex-1"
              placeholder="Digite um tema/conteúdo"
              value={temaInput}
              onChange={(e) => setTemaInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && adicionarTema()}
            />
            <button
              onClick={adicionarTema}
              className="px-3 py-2 bg-green-500 text-white rounded hover:bg-green-600"
            >
              Adicionar
            </button>
            <button
              onClick={sugerirTema}
              className="px-3 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-400"
            >
              🎲
            </button>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Digite um tema e clique em <b>Adicionar</b> ou pressione <b>Enter</b>. Se esquecer, ele será incluído automaticamente ao gerar o cronograma.
          </p>
          <div className="flex flex-wrap gap-2">
            {temas.map((t, idx) => (
              <span
                key={idx}
                className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full flex items-center gap-2"
              >
                {t}
                <button onClick={() => removerTema(t)} className="text-red-500 font-bold ml-1">×</button>
              </span>
            ))}
          </div>
          <label className="font-medium mt-2">Feriados/Dias sem aula:</label>
          <div className="flex gap-2">
            <input
              type="date"
              className="border p-2 rounded"
              onChange={e => adicionarFeriado(e.target.value)}
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {feriados.map((f, idx) => (
              <span
                key={idx}
                className="bg-gray-200 text-gray-700 px-3 py-1 rounded-full flex items-center gap-2"
              >
                {f}
                <button onClick={() => removerFeriado(f)} className="text-red-500 font-bold ml-1">×</button>
              </span>
            ))}
          </div>
        </div>
      </div>

      <button
        onClick={gerarCronogramaIA}
        disabled={loading}
        className="px-6 py-3 bg-indigo-600 text-white rounded hover:bg-indigo-700"
      >
        {loading ? "Gerando..." : "Gerar Cronograma"}
      </button>

      {/* Exibição do Cronograma Gerado */}
      {cronogramaGerado && (
        <div className="bg-white p-6 shadow rounded">
          <h2 className="text-xl font-bold mb-4">Cronograma Gerado</h2>
          <div className="bg-gray-100 p-4 rounded text-gray-800 whitespace-pre-wrap max-h-96 overflow-y-auto">
            {cronogramaGerado}
          </div>
          <button
            onClick={() => baixarPdf(cronogramaGerado)}
            className="mt-4 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 flex items-center gap-2"
          >
            <Download size={18} /> Baixar PDF
          </button>
        </div>
      )}

      {/* Histórico */}
      {historico.length > 0 && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">📜 Histórico de Cronogramas</h2>
            <button
              onClick={limparHistorico}
              className="text-red-700 px-4 py-2 bg-red-100 rounded-lg hover:bg-red-200"
            >
              Limpar Histórico
            </button>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            {historico.map((item, index) => (
              <div key={index} className="bg-white shadow p-4 rounded">
                <h3 className="text-indigo-600 font-bold">{item.disciplina} - {item.periodo}</h3>
                <p className="text-gray-600 text-sm">{item.dataInicio} a {item.dataFim}</p>
                <button
                  onClick={() => setModalCronograma(item)}
                  className="text-blue-600 hover:underline mt-2"
                >
                  Visualizar
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal de Ajuda */}
      {openAjuda && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-10">
          <div className="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
            <h2 className="text-2xl font-bold mb-4">Como usar o Organizador de Aula?</h2>
            <ul className="list-disc pl-6 text-gray-700 space-y-2">
              <li>Preencha disciplina, ano, período, datas e carga horária.</li>
              <li>Adicione todos os temas/conteúdos que deseja abordar.</li>
              <li>Inclua feriados ou dias sem aula para melhor distribuição.</li>
              <li>Clique em "Gerar Cronograma" para receber um planejamento detalhado e sugestões criativas.</li>
              <li>Você pode exportar o cronograma, salvar no histórico ou visualizar detalhes.</li>
            </ul>
            <button
              onClick={() => setOpenAjuda(false)}
              className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
            >
              Fechar
            </button>
          </div>
        </div>
      )}

      {/* Modal de Visualização do Histórico */}
      {modalCronograma && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-20">
          <div className="bg-white rounded p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-lg">
            <h3 className="text-xl font-bold mb-2">{modalCronograma.disciplina} - {modalCronograma.periodo}</h3>
            <p className="text-gray-600 text-sm mb-2">
              {modalCronograma.anoEscolar} | {modalCronograma.dataInicio} a {modalCronograma.dataFim}
            </p>
            <div className="mb-2">
              <span className="font-semibold">Temas:</span> {modalCronograma.temas.join(", ")}
            </div>
            <div className="mb-2">
              <span className="font-semibold">Carga semanal:</span> {modalCronograma.cargaSemanal} aulas
            </div>
            <div className="mb-2">
              <span className="font-semibold">Feriados:</span> {modalCronograma.feriados.length > 0 ? modalCronograma.feriados.join(", ") : "Nenhum"}
            </div>
            <div className="mt-4 bg-gray-100 p-4 rounded text-gray-800 whitespace-pre-wrap">
              {modalCronograma.cronograma}
            </div>
            <div className="flex justify-between mt-4">
              <button
                onClick={() => baixarPdf(modalCronograma.cronograma, `cronograma-${modalCronograma.disciplina}.pdf`)}
                className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 flex items-center gap-2"
              >
                <Download size={18} /> Baixar PDF
              </button>
              <button
                onClick={() => setModalCronograma(null)}
                className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}