import { useState, useEffect, useRef } from 'react'
import { jsPDF } from 'jspdf'
import axios from 'axios'

// Modelos de IA (exibição visual)
const MODELOS_IA_TEXTO = [
  { nome: 'ChatGPT', valor: 'chatgpt', descricao: 'OpenAI, referência mundial', cor: 'bg-green-600', icone: '💬' },
  { nome: 'Gemini', valor: 'gemini', descricao: 'Google, integração Bard', cor: 'bg-yellow-400', icone: '✨' },
  { nome: 'Claude', valor: 'claude', descricao: 'Anthropic, ética e contexto', cor: 'bg-blue-500', icone: '🧠' },
  { nome: 'Llama', valor: 'llama', descricao: 'Meta, open source', cor: 'bg-purple-600', icone: '🦙' },
  { nome: 'Copilot', valor: 'copilot', descricao: 'Microsoft, produtividade', cor: 'bg-blue-800', icone: '🤖' },
  { nome: 'Perplexity', valor: 'perplexity', descricao: 'Busca e respostas rápidas', cor: 'bg-pink-500', icone: '🔍' },
  { nome: 'OpenAI (usada aqui)', valor: 'openai', descricao: 'GPT-3.5 Turbo', cor: 'bg-indigo-600', icone: '🚀', destaque: true },
]

const SUGESTOES_COMANDO = [
  "Corrija como ENEM, atribua nota e justifique.",
  "Dê feedback construtivo para o aluno.",
  "Aponte erros conceituais e sugira melhorias.",
  "Corrija como vestibular tradicional.",
  "Corrija apenas ortografia e gramática.",
  "Destaque pontos positivos e negativos.",
  "Simule uma correção por competências.",
  "Corrija considerando critérios de criatividade.",
  "Dê uma devolutiva motivacional.",
]

const DICAS = [
  "Cole a resposta do aluno exatamente como recebida.",
  "Adicione o gabarito ou critérios para correção mais precisa.",
  "Experimente diferentes comandos para tipos de feedback.",
  "Salve e baixe o parecer para registro.",
  "Use a IA para sugestões de melhorias personalizadas.",
]

// Modal de ajuda
function AjudaModal({ open, onClose }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black bg-opacity-40">
      <div className="bg-white rounded-lg p-6 max-w-md w-full shadow-lg relative">
        <button
          aria-label="Fechar ajuda"
          onClick={onClose}
          className="absolute top-2 right-2 text-gray-400 hover:text-gray-700 text-xl"
        >×</button>
        <h2 className="text-xl font-bold mb-2">Como usar a Correção de Provas</h2>
        <ol className="list-decimal pl-5 space-y-2 text-sm">
          <li>Escolha o modelo de IA.</li>
          <li>Cole a resposta do aluno ou faça upload de um PDF/arquivo de texto para extrair a resposta automaticamente.</li>
          <li>Opcional: cole o gabarito ou critérios de correção para maior precisão.</li>
          <li>Escolha o tipo de correção (discursiva, redação, objetiva, etc).</li>
          <li>Escreva ou use um comando sugerido para orientar a IA (ex: "Corrija como ENEM, atribua nota e justifique.").</li>
          <li>Clique em <b>Corrigir com IA</b> e aguarde o parecer detalhado.</li>
          <li>Baixe o parecer em PDF ou consulte o histórico de correções.</li>
        </ol>
        <div className="mt-4 text-xs text-gray-500">
          Dica: Use comandos diferentes para tipos de feedback variados!
        </div>
      </div>
    </div>
  );
}

export default function CorrecaoProvas() {
  const [modeloIA, setModeloIA] = useState(MODELOS_IA_TEXTO[0].valor)
  const [respostaAluno, setRespostaAluno] = useState('')
  const [gabarito, setGabarito] = useState('')
  const [comando, setComando] = useState('Corrija como ENEM, atribua nota e justifique.')
  const [tipoCorrecao, setTipoCorrecao] = useState('discursiva')
  const [parecer, setParecer] = useState('')
  const [loading, setLoading] = useState(false)
  const [historico, setHistorico] = useState([])
  const [erro, setErro] = useState('')
  const [sucesso, setSucesso] = useState('')
  const [ajudaAberta, setAjudaAberta] = useState(false)
  const endRef = useRef(null)

  useEffect(() => {
    const historicoSalvo = localStorage.getItem('correcaoHistorico')
    if (historicoSalvo) setHistorico(JSON.parse(historicoSalvo))
  }, [])

  useEffect(() => {
    if (endRef.current) endRef.current.scrollIntoView({ behavior: 'smooth' })
  }, [historico])

  const salvarHistorico = (item) => {
    const novoHistorico = [item, ...historico]
    setHistorico(novoHistorico)
    localStorage.setItem('correcaoHistorico', JSON.stringify(novoHistorico))
  }

  const gerarParecerIA = async () => {
    if (!respostaAluno.trim()) {
      setErro('Cole a resposta do aluno!')
      setTimeout(() => setErro(''), 2000)
      return
    }
    setErro('')
    setSucesso('')
    setLoading(true)

    let prompt = `
Você é um corretor de provas experiente. 
Tipo de correção: ${tipoCorrecao}
Comando: ${comando}
${gabarito ? `Gabarito/Critérios de correção: ${gabarito}` : ''}
Resposta do aluno: ${respostaAluno}
Dê um parecer claro, atribua nota (se aplicável), destaque pontos positivos, negativos e sugira melhorias. Seja respeitoso e motivacional.
Final: "Correção gerada com apoio do IAula.ia - Inteligência Artificial na Educação."
    `

    try {
      const apiKey = import.meta.env.VITE_OPENAI_API_KEY
      const response = await axios.post('https://api.openai.com/v1/chat/completions', {
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.7,
      }, {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
      })

      const resposta = response.data.choices[0].message.content
      setParecer(resposta)
      salvarHistorico({
        respostaAluno, gabarito, comando, tipoCorrecao, parecer: resposta, data: new Date().toISOString()
      })
      setSucesso('Parecer gerado com sucesso!')
      setTimeout(() => setSucesso(''), 2000)
    } catch (error) {
      setErro('Erro ao gerar o parecer. Verifique a chave de API.')
      setTimeout(() => setErro(''), 2000)
    } finally {
      setLoading(false)
    }
  }

  const baixarParecerPdf = (texto, nomeArquivo = 'parecer-iaula.pdf') => {
    const doc = new jsPDF()
    const margin = 10
    const lineHeight = 10
    const maxLineWidth = 180
    let y = margin
    const lines = doc.splitTextToSize(texto, maxLineWidth)
  
    doc.setFont("times", "normal") // <-- aqui!
  
    lines.forEach(line => {
      if (y > 280) {
        doc.addPage()
        y = margin
        doc.setFont("times", "normal") // repete para cada página
      }
      doc.text(line, margin, y)
      y += lineHeight
    })
  
    doc.save(nomeArquivo)
    setSucesso('Parecer baixado como PDF!')
    setTimeout(() => setSucesso(''), 2000)
  }
  const limparHistorico = () => {
    if (window.confirm('Tem certeza que deseja apagar todo o histórico?')) {
      setHistorico([])
      localStorage.removeItem('correcaoHistorico')
    }
  }

  const sugestaoComando = () => {
    const aleatorio = SUGESTOES_COMANDO[Math.floor(Math.random() * SUGESTOES_COMANDO.length)]
    setComando(aleatorio)
  }

  // Upload e extração de texto de PDF/TXT
  const handleFileUpload = async (e) => {
    const file = e.target.files[0]
    if (!file) return

    if (file.type === "application/pdf") {
      const reader = new FileReader()
      reader.onload = async function () {
        const typedarray = new Uint8Array(this.result)
        const pdfjsLib = await import("pdfjs-dist/legacy/build/pdf")
        pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`
        const pdf = await pdfjsLib.getDocument({ data: typedarray }).promise
        let text = ''
        for (let i = 1; i <= pdf.numPages; i++) {
          const page = await pdf.getPage(i)
          const content = await page.getTextContent()
          text += content.items.map(item => item.str).join(' ') + '\n'
        }
        setRespostaAluno(text.trim())
      }
      reader.readAsArrayBuffer(file)
    } else if (file.type === "text/plain") {
      const reader = new FileReader()
      reader.onload = function () {
        setRespostaAluno(reader.result)
      }
      reader.readAsText(file)
    } else {
      setErro('Formato não suportado. Use PDF ou TXT.')
      setTimeout(() => setErro(''), 2000)
    }
  }

  return (
    <div className="flex flex-col gap-8 p-8 max-w-6xl mx-auto w-full">
      <AjudaModal open={ajudaAberta} onClose={() => setAjudaAberta(false)} />

      {/* Opções de IA de texto */}
      <div className="flex flex-wrap gap-4 mb-2" role="radiogroup" aria-label="Modelos de IA de texto">
        {MODELOS_IA_TEXTO.map((ia) => (
          <button
            key={ia.valor}
            aria-label={`Selecionar modelo ${ia.nome}`}
            onClick={() => setModeloIA(ia.valor)}
            className={`flex flex-col items-center px-4 py-3 rounded-lg border-2 shadow transition font-semibold
              ${modeloIA === ia.valor
                ? `${ia.cor} text-white border-indigo-700 scale-105`
                : ia.destaque
                  ? 'bg-white text-indigo-700 border-indigo-400 ring-2 ring-indigo-300'
                  : 'bg-white text-gray-800 border-gray-200 hover:bg-gray-50'}
              ${ia.destaque ? 'rounded-full' : ''}
            `}
            style={{ minWidth: 120 }}
          >
            <span className="text-2xl mb-1">{ia.icone}</span>
            <span>{ia.nome}</span>
            <span className="text-xs font-normal">{ia.descricao}</span>
            {ia.destaque && <span className="text-xs mt-1 font-bold text-indigo-700">Usada aqui</span>}
          </button>
        ))}
      </div>

      <div className="flex justify-between items-center mb-2">
        <h1 className="text-3xl font-bold text-gray-900">Correção de Provas (IAula)</h1>
        <button
          onClick={() => setAjudaAberta(true)}
          className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded hover:bg-indigo-100 text-sm font-semibold"
        >
          Ajuda
        </button>
      </div>

      {/* Dica rápida */}
      <div className="bg-indigo-50 rounded p-4 text-base text-indigo-800 mb-2">
        <strong>Dica:</strong> {DICAS[Math.floor(Math.random() * DICAS.length)]}
      </div>

      {/* Feedback visual */}
      {(erro || sucesso) && (
        <div className={`p-3 rounded text-center mb-2 ${erro ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
          {erro || sucesso}
        </div>
      )}

      {/* Formulário */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-white p-6 rounded-xl shadow border">
        <div className="flex flex-col gap-4">
          <textarea
            placeholder="Cole aqui a resposta do aluno (ou use o upload de arquivo)"
            className="border p-3 rounded-lg flex-1 text-lg min-h-[120px]"
            value={respostaAluno}
            onChange={(e) => setRespostaAluno(e.target.value)}
          />
          <label className="flex flex-col gap-2 text-sm text-gray-600">
            <span>Ou faça upload de PDF/TXT:</span>
            <input
              type="file"
              accept=".pdf,.txt"
              onChange={handleFileUpload}
              className="block border rounded p-2"
            />
          </label>
          <textarea
            placeholder="Cole aqui o gabarito, critérios ou resposta ideal (opcional)"
            className="border p-3 rounded-lg flex-1 text-lg min-h-[80px]"
            value={gabarito}
            onChange={(e) => setGabarito(e.target.value)}
          />
        </div>
        <div className="flex flex-col gap-4">
          <select className="border p-3 rounded-lg text-lg" value={tipoCorrecao} onChange={(e) => setTipoCorrecao(e.target.value)}>
            <option value="discursiva">📝 Discursiva</option>
            <option value="redacao">🖊️ Redação</option>
            <option value="objetiva">✅ Objetiva</option>
            <option value="outro">🔎 Outro</option>
          </select>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Comando para IA (ex: Corrija como ENEM...)"
              className="border p-3 rounded-lg flex-1 text-lg"
              value={comando}
              onChange={(e) => setComando(e.target.value)}
            />
            <button
              onClick={sugestaoComando}
              className="px-4 py-2 bg-yellow-400 text-gray-900 rounded-lg font-bold hover:bg-yellow-300 transition"
              title="Sugestão de comando"
            >
              🎲
            </button>
          </div>
          <button
            onClick={gerarParecerIA}
            disabled={loading}
            className="px-8 py-4 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 mt-4 text-xl font-bold w-full"
          >
            {loading ? 'Corrigindo com IA...' : 'Corrigir com IA'}
          </button>
        </div>
      </div>

      {/* Parecer Gerado */}
      {parecer && (
        <div className="mt-8 p-6 bg-white rounded-lg border shadow max-w-4xl mx-auto">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold mb-4 text-indigo-700">Parecer da Correção:</h2>
            <button onClick={() => setParecer('')} className="text-red-600 hover:text-red-800 font-bold">Fechar ❌</button>
          </div>
          <pre className="whitespace-pre-wrap text-gray-800 text-base">{parecer}</pre>
          <div className="mt-4 flex gap-3">
            <button
              onClick={() => baixarParecerPdf(parecer)}
              className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
            >
              Baixar Parecer em PDF
            </button>
          </div>
        </div>
      )}

      {/* Histórico de Correções */}
      {historico.length > 0 && (
        <div className="mt-10">
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-xl font-bold text-gray-800">📚 Histórico de Correções</h2>
            <button
              onClick={limparHistorico}
              className="px-4 py-2 bg-red-100 text-red-700 rounded hover:bg-red-200 text-sm font-semibold"
            >
              Limpar tudo
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {historico.map((item, index) => (
              <div key={index} className="bg-white border rounded-lg shadow p-4 flex flex-col gap-2">
                <div className="font-bold text-indigo-700 mb-1">Resposta do aluno:</div>
                <div className="text-sm text-gray-800 mb-2">{item.respostaAluno}</div>
                {item.gabarito && (
                  <>
                    <div className="font-bold text-gray-600">Gabarito/Critérios:</div>
                    <div className="text-xs text-gray-500 mb-2">{item.gabarito}</div>
                  </>
                )}
                <div className="text-xs text-gray-400 mb-2">{new Date(item.data).toLocaleDateString()}</div>
                <div className="flex gap-2 mt-auto">
                  <button
                    onClick={() => setParecer(item.parecer)}
                    title="Visualizar"
                    className="text-blue-600 hover:text-blue-800 text-lg"
                  >
                    🔍
                  </button>
                  <button
                    onClick={() => baixarParecerPdf(item.parecer, `parecer-${index + 1}.pdf`)}
                    title="Baixar PDF"
                    className="text-green-600 hover:text-green-800 text-lg"
                  >
                    📥
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <footer className="mt-10 text-center text-xs text-gray-400">
        IAula — Correção de provas com Inteligência Artificial. Para uso educacional.
      </footer>
      <div ref={endRef} />
    </div>
  )
}