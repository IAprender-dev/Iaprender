import { useState, useEffect } from 'react';
import axios from 'axios';

// Opções visuais de IA famosas (todas usam DeepAI por baixo dos panos)
const MODELOS_IA = [
  { nome: 'DALL·E', valor: 'dalle', descricao: 'IA da OpenAI, famosa pela criatividade', cor: 'bg-blue-500', icone: '🎨' },
  { nome: 'Midjourney', valor: 'midjourney', descricao: 'Muito usada para arte digital', cor: 'bg-purple-600', icone: '🌌' },
  { nome: 'Stable Diffusion', valor: 'stablediffusion', descricao: 'Open source, flexível e popular', cor: 'bg-green-600', icone: '🖌️' },
  { nome: 'Firefly', valor: 'firefly', descricao: 'Adobe, ideal para designers', cor: 'bg-red-500', icone: '🔥' },
  { nome: 'Gemini', valor: 'gemini', descricao: 'Google, integração com Bard', cor: 'bg-yellow-400', icone: '✨' },
  { nome: 'Leonardo', valor: 'leonardo', descricao: 'Detalhes e realismo impressionantes', cor: 'bg-pink-500', icone: '🦁' },
  // DeepAI sempre por último e destacada
  { nome: 'DeepAI', valor: 'deepai', descricao: 'Simples e rápida (usada aqui)', cor: 'bg-indigo-600', icone: '🧠', destaque: true },
];

const SUGESTOES = [
  {
    texto: "Sistema Solar",
    estilo: "Desenho",
    prompt: "Ilustração educativa do Sistema Solar mostrando todos os planetas, com cores vibrantes, nomes dos planetas e o Sol ao centro, estilo desenho didático para crianças."
  },
  {
    texto: "Ciclo da Água",
    estilo: "Cartoon",
    prompt: "Desenho educativo do ciclo da água, incluindo evaporação, condensação, precipitação e infiltração, com setas coloridas e personagens animados explicando cada etapa, estilo cartoon."
  },
  {
    texto: "Partes de uma planta",
    estilo: "Desenho",
    prompt: "Ilustração detalhada de uma planta mostrando raiz, caule, folhas, flores e frutos, com legendas e cores vivas, estilo desenho científico para ensino fundamental."
  },
  {
    texto: "Mapa do Brasil",
    estilo: "Foto Real",
    prompt: "Mapa do Brasil em alta resolução, com estados destacados por cores diferentes, nomes das capitais e principais rios, estilo foto realista e educativo."
  },
  {
    texto: "Pirâmide Alimentar",
    estilo: "Cartoon",
    prompt: "Desenho colorido de uma pirâmide alimentar, com alimentos ilustrados em cada nível, personagens felizes ao redor e legendas explicativas, estilo cartoon educativo."
  },
  {
    texto: "Experimento de Ciências",
    estilo: "Futurista",
    prompt: "Cena de laboratório futurista com crianças realizando experimentos científicos, tubos de ensaio coloridos, equipamentos modernos e atmosfera de descoberta, estilo futurista e educativo."
  },
  {
    texto: "Animais da Floresta",
    estilo: "Foto Real",
    prompt: "Imagem realista de uma floresta brasileira com diversos animais típicos como onça, macaco, tucano e capivara, todos em harmonia, estilo foto real para fins educativos."
  },
  {
    texto: "Fases da Lua",
    estilo: "Desenho",
    prompt: "Ilustração educativa mostrando as oito fases da Lua, cada uma com nome e representação visual, fundo estrelado e estilo desenho didático para crianças."
  },
];

const DICAS = [
  "Use frases curtas e claras para o tema.",
  "Adicione detalhes como cores ou época (ex: 'Sistema Solar colorido, estilo cartoon').",
  "Experimente diferentes estilos para o mesmo tema.",
  "Combine temas (ex: 'Mapa do Brasil com animais típicos').",
  "Peça para a IA mostrar um processo (ex: 'Ciclo da água passo a passo').",
];

const PROMPTS_SURPRESA = [
  "O ciclo de vida de uma borboleta em 4 etapas",
  "A cadeia alimentar da floresta amazônica",
  "O sistema digestivo humano desenhado para crianças",
  "A evolução dos meios de transporte",
  "A tabela periódica ilustrada",
  "O funcionamento de uma usina hidrelétrica",
  "A história do fogo: da pré-história à atualidade",
  "Como funciona a fotossíntese",
];

function AjudaModal({ open, onClose }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black bg-opacity-40">
      <div className="bg-white rounded-lg p-6 max-w-md w-full shadow-lg relative">
        <button
          aria-label="Fechar ajuda"
          onClick={onClose}
          className="absolute top-2 right-2 text-gray-400 hover:text-gray-700 text-xl"
        >×</button>
        <h2 className="text-xl font-bold mb-2">Ajuda Rápida</h2>
        <ul className="list-disc pl-5 space-y-2 text-sm">
          <li>Escolha um modelo visual de IA para inspirar seu resultado.</li>
          <li>Use as sugestões para prompts detalhados e educativos.</li>
          <li>Personalize o estilo, formato e preferências.</li>
          <li>Salve suas imagens favoritas para usar depois.</li>
          <li>Compartilhe ou baixe as imagens facilmente.</li>
          <li>Experimente o botão <b>Surpreenda-me</b> para ideias novas!</li>
        </ul>
      </div>
    </div>
  );
}

export default function CriarImagemIA() {
  const [prompt, setPrompt] = useState('');
  const [modeloIA, setModeloIA] = useState(MODELOS_IA[0].valor);
  const [modelo, setModelo] = useState('Standard');
  const [preferencia, setPreferencia] = useState('Rapidez');
  const [estilo, setEstilo] = useState('Desenho');
  const [formato, setFormato] = useState('Quadrado');
  const [loading, setLoading] = useState(false);
  const [imagens, setImagens] = useState([]);
  const [favoritos, setFavoritos] = useState([]);
  const [erro, setErro] = useState('');
  const [ajudaAberta, setAjudaAberta] = useState(false);
  const [showSugestaoUso, setShowSugestaoUso] = useState(false);

  // Persistência localStorage
  useEffect(() => {
    const imgs = localStorage.getItem('imagens');
    if (imgs) setImagens(JSON.parse(imgs));
    const favs = localStorage.getItem('favoritos');
    if (favs) setFavoritos(JSON.parse(favs));
  }, []);
  useEffect(() => {
    localStorage.setItem('imagens', JSON.stringify(imagens));
  }, [imagens]);
  useEffect(() => {
    localStorage.setItem('favoritos', JSON.stringify(favoritos));
  }, [favoritos]);

  // Prompt final
  const gerarPromptCompleto = () => {
    return `Imagem educativa no estilo ${estilo}, formato ${formato}, usando o modelo ${modelo} com preferência de ${preferencia}. Tema: ${prompt}`;
  };

  // Geração de imagem (sempre DeepAI)
  const gerarImagem = async () => {
    if (!prompt.trim()) {
      setErro('Digite um tema para a imagem!');
      return;
    }
    setErro('');
    setLoading(true);
    setShowSugestaoUso(false);
    try {
      const response = await axios.post(
        'https://api.deepai.org/api/text2img',
        { text: gerarPromptCompleto() },
        { headers: { 'Api-Key': '189dd87e-9399-4a7b-82c2-c1b722f2505f' } }
      );
      const novaImagem = {
        url: response.data.output_url,
        tema: prompt,
        modeloIA: MODELOS_IA.find(m => m.valor === modeloIA).nome,
        estilo,
        favorito: false,
        data: new Date().toLocaleString(),
        formato,
      };
      setImagens(prev => [novaImagem, ...prev]);
      setPrompt('');
      setShowSugestaoUso(true);
    } catch (error) {
      setErro('Erro ao gerar a imagem. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  // Baixar imagem
  const baixarImagem = (url, tema) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = `imagem-iaula-${tema.replace(/\s+/g, '-').toLowerCase()}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Excluir imagem
  const excluirImagem = (url) => {
    setImagens(imagens.filter(img => img.url !== url));
    setFavoritos(favoritos.filter(img => img.url !== url));
  };

  // Limpar tudo
  const limparHistorico = () => {
    if (window.confirm('Deseja realmente apagar todo o histórico de imagens?')) {
      setImagens([]);
      setFavoritos([]);
    }
  };

  // Favoritar imagem
  const favoritarImagem = (img) => {
    if (!favoritos.some(fav => fav.url === img.url)) {
      setFavoritos([img, ...favoritos]);
    }
  };

  // Compartilhar imagem
  const compartilharImagem = async (img) => {
    if (navigator.share) {
      try {
        await navigator.share({ title: img.tema, url: img.url });
      } catch (e) {}
    } else {
      await navigator.clipboard.writeText(img.url);
      setErro('Link copiado para a área de transferência!');
      setTimeout(() => setErro(''), 2000);
    }
  };

  // Surpreenda-me
  const promptSurpresa = () => {
    const aleatorio = PROMPTS_SURPRESA[Math.floor(Math.random() * PROMPTS_SURPRESA.length)];
    setPrompt(aleatorio);
    setEstilo('Desenho');
  };

  // Tooltip explicativo
  const Tooltip = ({ text }) => (
    <span className="ml-1 text-xs text-gray-400 cursor-help" title={text}>?</span>
  );

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8">
      <AjudaModal open={ajudaAberta} onClose={() => setAjudaAberta(false)} />

      <h1 className="text-3xl font-bold text-gray-800 mb-2 flex items-center gap-2">
        <span>🎨 IAula — Gerador de Imagens Educacionais</span>
        <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-1 rounded">Beta</span>
        <button
          aria-label="Abrir ajuda"
          onClick={() => setAjudaAberta(true)}
          className="ml-2 px-2 py-1 bg-indigo-50 text-indigo-700 rounded hover:bg-indigo-100 text-xs font-semibold"
        >
          Ajuda
        </button>
      </h1>
      <p className="text-gray-600 mb-6">Escolha o visual da IA, personalize o estilo e crie imagens incríveis para suas aulas!</p>

      {/* Feedback de erro */}
      {erro && (
        <div className="bg-red-100 text-red-700 p-2 rounded mb-2 flex items-center gap-2">
          <span>⚠️</span> {erro}
          <button onClick={() => setErro('')} className="ml-auto text-red-500 font-bold">x</button>
        </div>
      )}

      {/* Seleção visual de IA */}
      <div className="flex flex-wrap gap-4 mb-4" role="radiogroup" aria-label="Modelos de IA">
        {MODELOS_IA.map((ia) => (
          <button
            key={ia.valor}
            aria-label={`Selecionar modelo ${ia.nome}`}
            onClick={() => setModeloIA(ia.valor)}
            className={`flex flex-col items-center px-4 py-3 rounded-lg border-2 shadow transition font-semibold
              ${modeloIA === ia.valor
                ? `${ia.cor} text-white border-indigo-700 scale-105`
                : ia.destaque
                  ? 'bg-white text-indigo-700 border-indigo-400 ring-2 ring-indigo-300'
                  : 'bg-white text-gray-800 border-gray-200 hover:bg-gray-50'}
              ${ia.destaque ? 'rounded-full' : ''}
            `}
            style={{ minWidth: 120 }}
          >
            <span className="text-2xl mb-1">{ia.icone}</span>
            <span>{ia.nome}</span>
            <span className="text-xs font-normal">{ia.descricao}</span>
            {ia.destaque && <span className="text-xs mt-1 font-bold text-indigo-700">Usada aqui</span>}
          </button>
        ))}
      </div>

      {/* Prompt e filtros */}
      <div className="bg-white rounded-lg shadow p-6 space-y-4">
        <div className="flex flex-col md:flex-row gap-4">
          <input
            type="text"
            aria-label="Tema da imagem"
            placeholder="Digite o tema da imagem (ex: Sistema Solar)"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="border p-3 rounded-lg flex-1 text-lg"
            autoFocus
            disabled={loading}
          />
          <button
            aria-label="Gerar imagem"
            onClick={gerarImagem}
            disabled={loading}
            className="px-6 py-3 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700 transition"
          >
            {loading ? (
              <span className="flex items-center gap-2">
                <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="none" stroke="white" strokeWidth="4"/></svg>
                Gerando...
              </span>
            ) : (
              'Gerar Imagem'
            )}
          </button>
          <button
            aria-label="Surpreenda-me"
            onClick={promptSurpresa}
            disabled={loading}
            className="px-4 py-3 bg-yellow-400 text-gray-900 rounded-lg font-bold hover:bg-yellow-300 transition"
            title="Gerar um tema educativo aleatório"
          >
            🎲 Surpreenda-me!
          </button>
        </div>
        {/* Filtros */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <label className="text-sm font-semibold">Modelo
              <Tooltip text="Define o nível de detalhes e qualidade da imagem." />
            </label>
            <select className="border p-2 rounded-lg w-full" value={modelo} onChange={(e) => setModelo(e.target.value)} disabled={loading}>
              <option>Standard</option>
              <option>HD</option>
              <option>Genius</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-semibold">Preferência
              <Tooltip text="Escolha entre gerar mais rápido ou com mais qualidade." />
            </label>
            <select className="border p-2 rounded-lg w-full" value={preferencia} onChange={(e) => setPreferencia(e.target.value)} disabled={loading}>
              <option>Rapidez</option>
              <option>Qualidade</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-semibold">Estilo
              <Tooltip text="O visual predominante da imagem." />
            </label>
            <select className="border p-2 rounded-lg w-full" value={estilo} onChange={(e) => setEstilo(e.target.value)} disabled={loading}>
              <option>Desenho</option>
              <option>Foto Real</option>
              <option>Cartoon</option>
              <option>Futurista</option>
              <option>Vintage</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-semibold">Formato
              <Tooltip text="Proporção da imagem gerada." />
            </label>
            <select className="border p-2 rounded-lg w-full" value={formato} onChange={(e) => setFormato(e.target.value)} disabled={loading}>
              <option>Quadrado</option>
              <option>Retrato (vertical)</option>
              <option>Paisagem (horizontal)</option>
            </select>
          </div>
        </div>
        {/* Sugestões rápidas */}
        <div className="flex flex-wrap gap-2 mt-2">
          {SUGESTOES.map((sug, idx) => (
            <button
              key={idx}
              aria-label={`Usar sugestão: ${sug.texto}`}
              onClick={() => { setPrompt(sug.prompt); setEstilo(sug.estilo); }}
              className="bg-gray-200 text-gray-700 px-3 py-1 rounded-full hover:bg-gray-300 text-sm"
              disabled={loading}
            >
              {sug.texto}
            </button>
          ))}
        </div>
        {/* Dicas rápidas */}
        <div className="bg-indigo-50 rounded p-3 mt-4 text-sm text-indigo-800">
          <strong>Dica:</strong> {DICAS[Math.floor(Math.random() * DICAS.length)]}
        </div>
        {/* Preview do prompt final */}
        <div className="text-xs text-gray-500 mt-2">
          <strong>Prompt final:</strong> {gerarPromptCompleto()}
        </div>
      </div>

      {/* Sugestão de uso após geração */}
      {showSugestaoUso && (
        <div className="bg-green-50 text-green-800 rounded p-3 text-sm flex items-center gap-2">
          <span>✅</span>
          Imagem gerada! Dica: use-a em slides, cartazes, atividades ou compartilhe com seus colegas!
        </div>
      )}

      {/* Favoritos */}
      {favoritos.length > 0 && (
        <div>
          <h2 className="text-xl font-semibold text-pink-600 mb-2 flex items-center gap-2">⭐ Favoritos</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {favoritos.map((img, idx) => (
              <div key={idx} className="border-2 border-pink-400 rounded-lg p-4 bg-white shadow flex flex-col items-center relative">
                <img src={img.url} alt={`Imagem gerada: ${img.tema}`} className="rounded mb-3 max-h-48 object-contain border" />
                <p className="text-center text-sm text-gray-700 mb-1">{img.tema}</p>
                <span className="text-xs text-indigo-500 mb-1">{img.modeloIA} • {img.estilo}</span>
                <span className="text-xs text-gray-400 mb-2">{img.data}</span>
                <div className="flex gap-2">
                  <button
                    aria-label="Baixar imagem"
                    onClick={() => baixarImagem(img.url, img.tema)}
                    className="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600 text-xs"
                  >
                    📥 Baixar
                  </button>
                  <button
                    aria-label="Excluir imagem"
                    onClick={() => excluirImagem(img.url)}
                    className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 text-xs"
                  >
                    🗑️ Excluir
                  </button>
                  <button
                    aria-label="Compartilhar imagem"
                    onClick={() => compartilharImagem(img)}
                    className="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 text-xs"
                  >
                    📤 Compartilhar
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Histórico de imagens */}
      {imagens.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-xl font-semibold text-gray-700">Histórico de Imagens</h2>
            <button
              aria-label="Limpar histórico"
              onClick={limparHistorico}
              className="px-4 py-2 bg-red-100 text-red-700 rounded hover:bg-red-200 text-sm font-semibold"
            >
              Limpar tudo
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {imagens.map((img, idx) => (
              <div key={idx} className="border rounded-lg p-4 bg-white shadow flex flex-col items-center relative group">
                <img src={img.url} alt={`Imagem gerada: ${img.tema}`} className="rounded mb-3 max-h-48 object-contain border" />
                <p className="text-center text-sm text-gray-700 mb-1">{img.tema}</p>
                <span className="text-xs text-indigo-500 mb-1">{img.modeloIA} • {img.estilo}</span>
                <span className="text-xs text-gray-400 mb-2">{img.data}</span>
                <div className="flex gap-2">
                  <button
                    aria-label="Baixar imagem"
                    onClick={() => baixarImagem(img.url, img.tema)}
                    className="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600 text-xs"
                  >
                    📥 Baixar
                  </button>
                  <button
                    aria-label="Excluir imagem"
                    onClick={() => excluirImagem(img.url)}
                    className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 text-xs"
                  >
                    🗑️ Excluir
                  </button>
                  <button
                    aria-label="Favoritar imagem"
                    onClick={() => favoritarImagem(img)}
                    className="px-3 py-1 bg-yellow-300 text-yellow-900 rounded hover:bg-yellow-400 text-xs"
                    title="Favoritar"
                  >
                    ⭐
                  </button>
                  <button
                    aria-label="Compartilhar imagem"
                    onClick={() => compartilharImagem(img)}
                    className="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 text-xs"
                  >
                    📤 Compartilhar
                  </button>
                </div>
                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition">
                  <span className="bg-indigo-100 text-indigo-700 px-2 py-1 rounded text-xs">{img.formato}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Ajuda extra para alunos */}
      <div className="mt-10 bg-indigo-50 rounded-lg p-6 text-indigo-900">
        <h3 className="font-bold mb-2">💡 Dicas para criar imagens educativas incríveis:</h3>
        <ul className="list-disc pl-6 space-y-1 text-sm">
          <li>Experimente diferentes estilos e formatos para ver qual comunica melhor sua ideia.</li>
          <li>Use o botão <b>Surpreenda-me</b> para descobrir temas novos.</li>
          <li>Salve suas imagens favoritas para usar depois.</li>
          <li>Combine sugestões e filtros para criar algo único.</li>
          <li>Use as imagens para ilustrar resumos, slides, cartazes e atividades!</li>
        </ul>
      </div>

      {/* Créditos */}
      <footer className="mt-10 text-center text-xs text-gray-400">
        Imagens geradas com IA DeepAI. Para uso educacional.
      </footer>
    </div>
  );
}