import { Link } from "react-router-dom";
import { 
  BookOpen, Bot, Image, ListChecks, BookCopy, 
  PenLine, Calendar, FileText, Settings, HelpCircle, Home as HomeIcon, BarChart3
} from "lucide-react";
import { useEffect, useState } from "react";

const ferramentas = [
  { nome: "Home", href: "/", icone: HomeIcon },
  { nome: "Apoio aos Estudos", href: "/apoio", icone: BookOpen },
  { nome: "Tutor Virtual", href: "/tutor-virtual", icone: Bot },
  { nome: "Criar Imagem Educacional", href: "/criar-imagem", icone: Image },
  { nome: "Gerador de Atividades", href: "/gerador-atividades", icone: ListChecks },
  { nome: "Materiais Didáticos IA", href: "/materiais-didaticos", icone: BookCopy },
  { nome: "Correção de Provas", href: "/correcao-provas", icone: PenLine },
  { nome: "Planejamento de Aula", href: "/planejamento", icone: Calendar },
  { nome: "Modelos de Planejamento", href: "/modelos-prontos", icone: FileText },
];

const administracao = [
  { nome: "Configurações", href: "/configuracoes", icone: Settings },
  { nome: "Suporte", href: "/suporte", icone: HelpCircle },
];

// Função de contador animado
function useContadorAnimado(valorFinal, duracao = 1000) {
  const [valor, setValor] = useState(0);

  useEffect(() => {
    let start = 0;
    const incremento = valorFinal / (duracao / 16);
    const interval = setInterval(() => {
      start += incremento;
      if (start >= valorFinal) {
        start = valorFinal;
        clearInterval(interval);
      }
      setValor(Math.floor(start));
    }, 16);

    return () => clearInterval(interval);
  }, [valorFinal, duracao]);

  return valor;
}

export default function Home() {
  const [atividades, setAtividades] = useState(0);
  const [materiais, setMateriais] = useState(0);

  useEffect(() => {
    const historicoAtividades = JSON.parse(localStorage.getItem("atividadesHistorico")) || [];
    const historicoMateriais = JSON.parse(localStorage.getItem("materiaisHistorico")) || [];

    setAtividades(historicoAtividades.length);
    setMateriais(historicoMateriais.length);
  }, []);

  const atividadesAnimado = useContadorAnimado(atividades);
  const materiaisAnimado = useContadorAnimado(materiais);
  const planejamentosAnimado = useContadorAnimado(0); // Podemos mudar depois

  return (
    <div className="space-y-10">
      {/* Painel de Estatísticas */}
      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow hover:shadow-lg transition group border">
          <div className="flex items-center gap-4">
            <BarChart3 className="w-10 h-10 text-indigo-600 group-hover:text-indigo-700" />
            <div>
              <div className="text-gray-500 text-sm">Atividades Geradas</div>
              <div className="text-2xl font-bold text-gray-700">{atividadesAnimado}</div>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow hover:shadow-lg transition group border">
          <div className="flex items-center gap-4">
            <BookCopy className="w-10 h-10 text-indigo-600 group-hover:text-indigo-700" />
            <div>
              <div className="text-gray-500 text-sm">Materiais Criados</div>
              <div className="text-2xl font-bold text-gray-700">{materiaisAnimado}</div>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow hover:shadow-lg transition group border">
          <div className="flex items-center gap-4">
            <Calendar className="w-10 h-10 text-indigo-600 group-hover:text-indigo-700" />
            <div>
              <div className="text-gray-500 text-sm">Planejamentos</div>
              <div className="text-2xl font-bold text-gray-700">{planejamentosAnimado}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Ferramentas */}
      <div>
        <h2 className="text-2xl font-bold text-indigo-700 mb-4">Ferramentas IAula</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {ferramentas.map((item) => (
            <Link
              key={item.nome}
              to={item.href}
              className="group bg-white border rounded-2xl p-6 flex flex-col items-center text-center shadow hover:shadow-lg hover:border-indigo-500 transition"
            >
              <item.icone className="h-12 w-12 text-indigo-500 group-hover:text-indigo-700 transition" />
              <h3 className="mt-4 text-lg font-semibold text-gray-700 group-hover:text-indigo-700">
                {item.nome}
              </h3>
            </Link>
          ))}
        </div>
      </div>

      {/* Administração */}
      <div>
        <h2 className="text-2xl font-bold text-indigo-700 mb-4">Administração</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-6">
          {administracao.map((item) => (
            <Link
              key={item.nome}
              to={item.href}
              className="group bg-white border rounded-2xl p-6 flex flex-col items-center text-center shadow hover:shadow-lg hover:border-indigo-500 transition"
            >
              <item.icone className="h-12 w-12 text-indigo-500 group-hover:text-indigo-700 transition" />
              <h3 className="mt-4 text-lg font-semibold text-gray-700 group-hover:text-indigo-700">
                {item.nome}
              </h3>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
