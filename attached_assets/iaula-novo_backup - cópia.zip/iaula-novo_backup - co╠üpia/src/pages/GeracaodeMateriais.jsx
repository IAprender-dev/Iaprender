import { useState, useEffect } from "react";
import { jsPDF } from "jspdf";
import axios from "axios";

const DISCIPLINAS = [
  "Matemática", "Português", "Ciências", "História", "Geografia", "Física", "Química", "Biologia"
];

const FORMATOS_MATERIAIS = [
  "Resumo", "Apostila", "Explicação", "Mapa Mental"
];

const NIVEIS_DIFICULDADE = ["Fácil", "Intermediário", "Avançado"];

const ANOS_ESCOLARES = [
  "1º Ano Fundamental", "2º Ano Fundamental", "3º Ano Fundamental", "4º Ano Fundamental",
  "5º Ano Fundamental", "6º Ano Fundamental", "7º Ano Fundamental", "8º Ano Fundamental",
  "9º Ano Fundamental", "1ª Série Médio", "2ª Série Médio", "3ª Série Médio"
];

const SUGESTOES_TEMAS = [
  "Resumo sobre a Revolução Francesa", "Apostila de Geometria", "Explicação de Fotossíntese",
  "Resumo sobre Sistema Solar", "Apostila de Gramática", "Explicação sobre Energia e Trabalho"
];

const DICAS = [
  "Use temas como 'Resumo sobre a Revolução Francesa' ou 'Apostila de Geometria'.",
  "Escolha o formato para personalizar o tipo de material (resumo, apostila, explicação, mapa mental).",
  "O material gerado é para estudo, ensino e apoio ao aprendizado.",
  "Inclua palavras-chave ou tópicos para resumos e mapas mentais mais completos."
];

export default function GeracaodeMateriais() {
  // Estados principais
  const [tema, setTema] = useState("");
  const [disciplina, setDisciplina] = useState(DISCIPLINAS[0]);
  const [anoEscolar, setAnoEscolar] = useState(ANOS_ESCOLARES[0]);
  const [formatoMaterial, setFormatoMaterial] = useState(FORMATOS_MATERIAIS[0]);
  const [nivelDificuldade, setNivelDificuldade] = useState(NIVEIS_DIFICULDADE[0]);

  const [materialGerado, setMaterialGerado] = useState(""); // Armazenar o material gerado
  const [historico, setHistorico] = useState([]); // Histórico de materiais gerados

  // Modal de ajuda e visualização
  const [modalMaterial, setModalMaterial] = useState(null);
  const [openModalAjuda, setOpenModalAjuda] = useState(false);

  const [loading, setLoading] = useState(false);
  const [erro, setErro] = useState("");
  const [sucesso, setSucesso] = useState("");

  useEffect(() => {
    const historicoSalvo = localStorage.getItem("materiaisHistorico");
    if (historicoSalvo) setHistorico(JSON.parse(historicoSalvo));
  }, []);

  const salvarHistorico = (material) => {
    const novoHistorico = [material, ...historico];
    setHistorico(novoHistorico);
    localStorage.setItem("materiaisHistorico", JSON.stringify(novoHistorico));
  };

  const gerarMaterialIA = async () => {
    if (!tema.trim()) {
      setErro("Digite um tema para gerar o material!");
      setTimeout(() => setErro(""), 2000);
      return;
    }

    setErro("");
    setSucesso("");
    setLoading(true);

    // PROMPT AJUSTADO PARA MATERIAL DE ESTUDO, NÃO QUESTÕES!
    const prompt = `
Você é um professor especialista em ${disciplina} para o ${anoEscolar}.
Sua tarefa é criar um MATERIAL DIDÁTICO para ENSINO e APRENDIZADO no formato: ${formatoMaterial}, sobre o tema: "${tema}", para o nível de dificuldade: ${nivelDificuldade}.

Diretrizes:
- Resumo: Crie um texto resumido, claro e objetivo, destacando os principais pontos do tema.
- Apostila: Elabore um material completo, organizado em seções e subtítulos, com explicações detalhadas, exemplos e dicas.
- Explicação: Faça uma explicação didática, como se estivesse ensinando para um estudante, usando linguagem acessível e exemplos práticos.
- Mapa Mental: Liste os principais conceitos, tópicos e conexões do tema em formato de tópicos e subtópicos.

O material deve ser adequado para estudo e apoio ao aprendizado, sem incluir questões ou perguntas.
Ao final, sugira pelo menos um recurso visual (imagem, infográfico ou vídeo) que enriqueceria o material.
Capriche na didática, clareza e organização!
`;

    try {
      const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
      const response = await axios.post(
        "https://api.openai.com/v1/chat/completions",
        {
          model: "gpt-3.5-turbo",
          messages: [{ role: "user", content: prompt }],
          temperature: 0.7
        },
        {
          headers: {
            Authorization: `Bearer ${apiKey}`,
            "Content-Type": "application/json"
          }
        }
      );

      const material = response.data.choices[0].message.content;
      setMaterialGerado(material);

      salvarHistorico({
        tema,
        disciplina,
        anoEscolar,
        formato: formatoMaterial,
        dificuldade: nivelDificuldade,
        material,
        data: new Date().toISOString()
      });

      setSucesso("Material gerado com sucesso!");
      setTimeout(() => setSucesso(""), 3000);
    } catch (error) {
      setErro("Erro ao gerar o material. Verifique sua chave de API.");
    } finally {
      setLoading(false);
    }
  };

  const baixarPdfMaterial = (texto, nomeArquivo = "material-didatico.pdf") => {
    const doc = new jsPDF();
    const margin = 10;
    const lineHeight = 10;
    const maxLineWidth = 180;
    let y = margin;
    const lines = doc.splitTextToSize(texto, maxLineWidth);

    lines.forEach((line) => {
      if (y > 280) {
        doc.addPage();
        y = margin;
      }
      doc.text(line, margin, y);
      y += lineHeight;
    });

    doc.save(nomeArquivo);
    setSucesso("PDF baixado com sucesso!");
    setTimeout(() => setSucesso(""), 2000);
  };

  const limparHistorico = () => {
    if (window.confirm("Tem certeza que deseja limpar todo o histórico?")) {
      setHistorico([]);
      localStorage.removeItem("materiaisHistorico");
    }
  };

  const sugerirTema = () => {
    const aleatorio = SUGESTOES_TEMAS[Math.floor(Math.random() * SUGESTOES_TEMAS.length)];
    setTema(aleatorio);
  };

  return (
    <div className="flex flex-col max-w-5xl mx-auto p-8 gap-8">
      {/* Cabeçalho */}
      <div className="flex justify-between items-center">
      <h1 className="text-3xl font-bold">📚 Geração de Materiais Didáticos (Estudo e Ensino)</h1>
        <button
          onClick={() => setOpenModalAjuda(true)}
          className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
        >
          Ajuda
        </button>
      </div>

      {/* Dicas */}
      <div className="bg-indigo-100 text-indigo-800 p-4 rounded-lg">
        <strong>Dica:</strong> {DICAS[Math.floor(Math.random() * DICAS.length)]}
      </div>

      {/* Feedback */}
      {erro && <div className="text-red-600 bg-red-100 p-3 rounded">{erro}</div>}
      {sucesso && <div className="text-green-600 bg-green-100 p-3 rounded">{sucesso}</div>}

      {/* Formulário */}
      <div className="grid md:grid-cols-2 gap-6 bg-white p-6 rounded shadow">
        <div className="flex flex-col gap-4">
          <select
            className="border p-3 rounded"
            value={disciplina}
            onChange={(e) => setDisciplina(e.target.value)}
          >
            {DISCIPLINAS.map((d) => (
              <option key={d}>{d}</option>
            ))}
          </select>
          <select
            className="border p-3 rounded"
            value={anoEscolar}
            onChange={(e) => setAnoEscolar(e.target.value)}
          >
            {ANOS_ESCOLARES.map((ano) => (
              <option key={ano}>{ano}</option>
            ))}
          </select>
          <select
            className="border p-3 rounded"
            value={formatoMaterial}
            onChange={(e) => setFormatoMaterial(e.target.value)}
          >
            {FORMATOS_MATERIAIS.map((formato) => (
              <option key={formato}>{formato}</option>
            ))}
          </select>
          <select
            className="border p-3 rounded"
            value={nivelDificuldade}
            onChange={(e) => setNivelDificuldade(e.target.value)}
          >
            {NIVEIS_DIFICULDADE.map((nivel) => (
              <option key={nivel}>{nivel}</option>
            ))}
          </select>
        </div>

        <div className="flex flex-col gap-4">
          <textarea
            className="border p-3 rounded h-32"
            placeholder="Digite o tema ou conteúdo do material"
            value={tema}
            onChange={(e) => setTema(e.target.value)}
          ></textarea>
          <button
            onClick={sugerirTema}
            className="px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-400"
          >
            🎲 Surpreenda-me!
          </button>
        </div>
      </div>

      <button
        onClick={gerarMaterialIA}
        disabled={loading}
        className="px-6 py-3 bg-indigo-600 text-white rounded hover:bg-indigo-700"
      >
        {loading ? "Gerando..." : "Gerar Material de Estudo"}
      </button>

      {/* Exibição do Material Gerado */}
      {materialGerado && (
        <div className="bg-white p-6 shadow rounded">
          <h2 className="text-xl font-bold mb-4">📖 Material Gerado para Estudo</h2>
          <div className="bg-gray-100 p-4 rounded text-gray-800 whitespace-pre-wrap max-h-64 overflow-y-auto">
            {materialGerado}
          </div>
          <button
            onClick={() => baixarPdfMaterial(materialGerado)}
            className="mt-4 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
          >
            Baixar PDF
          </button>
        </div>
      )}

      {/* Histórico */}
      {historico.length > 0 && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">📜 Histórico de Materiais</h2>
            <button
              onClick={limparHistorico}
              className="text-red-700 px-4 py-2 bg-red-100 rounded-lg hover:bg-red-200"
            >
              Limpar Histórico
            </button>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            {historico.map((item, index) => (
              <div key={index} className="bg-white shadow p-4 rounded">
                <h3 className="text-indigo-600 font-bold">{item.tema}</h3>
                <p className="text-gray-600">
                  {item.anoEscolar} • {item.disciplina} • {item.formato}
                </p>
                <button
                  onClick={() => setModalMaterial(item)}
                  className="text-blue-600 mt-2 hover:underline"
                >
                  Visualizar
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal de Ajuda */}
      {openModalAjuda && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-10">
          <div className="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
            <h2 className="text-2xl font-bold mb-4">Como usar o Gerador de Materiais?</h2>
            <p>
            <b>Este módulo NÃO gera exercícios.</b> Ele gera apenas <b>materiais de estudo</b> como <b>resumos, apostilas, explicações e mapas mentais</b>.  
            O foco é apoiar o aluno no aprendizado, e não avaliação!
            </p>
            <button
              onClick={() => setOpenModalAjuda(false)}
              className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
            >
              Fechar
            </button>
          </div>
        </div>
      )}

      {/* Modal de Visualização do Histórico */}
      {modalMaterial && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-20">
          <div className="bg-white rounded p-6 max-w-2xl w-full max-h-96 overflow-y-auto shadow-lg">
            <h3 className="text-xl font-bold">{modalMaterial.tema}</h3>
            <p className="text-gray-600">
              {modalMaterial.anoEscolar} • {modalMaterial.disciplina} • {modalMaterial.formato}
            </p>
            <div className="mt-4 bg-gray-100 p-4 rounded text-gray-800 whitespace-pre-wrap">
              {modalMaterial.material}
            </div>
            <div className="flex justify-between mt-4">
              <button
                onClick={() => baixarPdfMaterial(modalMaterial.material, `material-${modalMaterial.tema}.pdf`)}
                className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
              >
                Baixar PDF
              </button>
              <button
                onClick={() => setModalMaterial(null)}
                className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
