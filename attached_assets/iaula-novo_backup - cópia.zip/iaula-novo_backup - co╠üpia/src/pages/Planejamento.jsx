import { useState, useEffect } from 'react'
import { jsPDF } from 'jspdf'
import axios from 'axios'
import Modal from '../components/Modal'
import ModalObjetivos from '../components/ModalObjetivos'

// Opções visuais de IA de planejamento (todas usam sua API por baixo)
const MODELOS_IA_PLANO = [
  { nome: 'ChatGPT', valor: 'chatgpt', descricao: 'OpenAI, referência mundial', cor: 'bg-green-600', icone: '💬' },
  { nome: 'Gemini', valor: 'gemini', descricao: 'Google, integração Bard', cor: 'bg-yellow-400', icone: '✨' },
  { nome: 'Claude', valor: 'claude', descricao: 'Anthropic, ética e contexto', cor: 'bg-blue-500', icone: '🧠' },
  { nome: 'Llama', valor: 'llama', descricao: 'Meta, open source', cor: 'bg-purple-600', icone: '🦙' },
  { nome: 'Copilot', valor: 'copilot', descricao: 'Microsoft, produtividade', cor: 'bg-blue-800', icone: '🤖' },
  { nome: 'Perplexity', valor: 'perplexity', descricao: 'Busca e respostas rápidas', cor: 'bg-pink-500', icone: '🔍' },
  { nome: 'OpenAI (usada aqui)', valor: 'openai', descricao: 'GPT-3.5 Turbo', cor: 'bg-indigo-600', icone: '🚀', destaque: true },
]

const SUGESTOES_TEMA = [
  "A importância da água para a vida",
  "Sustentabilidade ambiental na escola",
  "Matemática no cotidiano",
  "História da abolição da escravatura",
  "O corpo humano e seus sistemas",
  "Tecnologias do século XXI",
  "Arte e cultura afro-brasileira",
  "Educação financeira para crianças",
  "Cidadania e direitos humanos",
  "Aquecimento global e suas consequências"
]

const DICAS = [
  "Seja específico no tema para planos mais personalizados.",
  "Inclua observações sobre necessidades da turma.",
  "Use o modo Premium para sugestões de recursos e inclusão.",
  "Experimente diferentes modelos e tons de linguagem.",
  "Salve e reutilize planos do histórico!",
]

export default function Planejamento() {
  const [modeloIA, setModeloIA] = useState(MODELOS_IA_PLANO[0].valor)
  const [tema, setTema] = useState('')
  const [serie, setSerie] = useState('')
  const [disciplina, setDisciplina] = useState('')
  const [duracao, setDuracao] = useState('')
  const [modeloPlano, setModeloPlano] = useState('tradicional')
  const [planoGerado, setPlanoGerado] = useState('')
  const [loading, setLoading] = useState(false)
  const [historico, setHistorico] = useState([])
  const [openModal, setOpenModal] = useState(false)
  const [planoSelecionado, setPlanoSelecionado] = useState('')
  const [objetivosSelecionados, setObjetivosSelecionados] = useState([])
  const [openModalObjetivos, setOpenModalObjetivos] = useState(false)
  const [observacoes, setObservacoes] = useState('')
  const [tomLinguagem, setTomLinguagem] = useState('formal')
  const [modoPremium, setModoPremium] = useState(false)
  const [erro, setErro] = useState('')
  const [sucesso, setSucesso] = useState('')

  useEffect(() => {
    const historicoSalvo = localStorage.getItem('planejamentoHistorico')
    if (historicoSalvo) setHistorico(JSON.parse(historicoSalvo))
  }, [])

  const salvarHistorico = (plano) => {
    const novoHistorico = [plano, ...historico]
    setHistorico(novoHistorico)
    localStorage.setItem('planejamentoHistorico', JSON.stringify(novoHistorico))
  }

  const gerarPlanoIA = async () => {
    if (!tema.trim()) {
      setErro('Digite o tema da aula!')
      setTimeout(() => setErro(''), 2000)
      return
    }
    setErro('')
    setSucesso('')
    setLoading(true)

    let estiloPlano = ''
    if (modeloPlano === 'tradicional') {
      estiloPlano = 'utilizando abordagem tradicional expositiva com atividades práticas.'
    } else if (modeloPlano === 'ativo') {
      estiloPlano = 'aplicando metodologias ativas com foco em participação e projetos.'
    } else if (modeloPlano === 'invertido') {
      estiloPlano = 'seguindo o modelo de sala de aula invertida, com estudo prévio e discussão em sala.'
    }

    let prompt = `
    Você é um especialista em educação e design de experiências de aprendizagem. Elabore um plano de aula inovador, detalhado e prático, seguindo as orientações abaixo:
    
    1. **Contextualização**: 
       - Tema: "${tema}"
       - Série/Ano: ${serie || 'não informado'}
       - Disciplina: ${disciplina || 'não informado'}
       - Duração: ${duracao || 'não informado'}
       - Perfil da turma: ${observacoes || 'não informado'}
    
    2. **Objetivos de Aprendizagem**: 
       - Liste objetivos claros, mensuráveis e alinhados à BNCC ou currículo nacional.
       - Se possível, relacione com competências gerais e específicas.
    
    3. **Roteiro Detalhado da Aula**: 
       - Divida em etapas (início, desenvolvimento, fechamento) com tempos sugeridos.
       - Descreva atividades inovadoras, interativas e diversificadas (expositivas, colaborativas, mão na massa, gamificação, etc).
       - Inclua sugestões de perguntas para sondagem, debate e engajamento dos alunos.
    
    4. **Estratégias de Inclusão e Acessibilidade**: 
       - Sugira adaptações para alunos com diferentes necessidades (ex: deficiência visual, auditiva, TDAH, altas habilidades).
       - Recomende práticas de ensino inclusivo e linguagem acessível.
    
    5. **Recursos Didáticos e Tecnológicos**: 
       - Indique vídeos, aplicativos, sites, jogos digitais e materiais concretos.
       - Sugira pelo menos um recurso digital gratuito e um recurso interdisciplinar.
    
    6. **Avaliação**: 
       - Proponha formas de avaliação formativa (durante a aula) e somativa (após a aula).
       - Inclua exemplos de instrumentos (autoavaliação, rubricas, quizzes, portfólio, etc).
    
    7. **Extensão e Tarefa para Casa**: 
       - Sugira atividades de aprofundamento, projetos ou desafios para casa.
    
    8. **Adaptação para Ensino Remoto ou Híbrido**: 
       - Dê dicas para adaptar as atividades ao ensino remoto, com ferramentas digitais.
    
    9. **Mensagem Final**: 
       - Inclua uma mensagem motivacional para o(a) professor(a) sobre o impacto da educação inovadora.
    
    10. **Assinatura**: 
       - Finalize com: "Plano criado com apoio do IAula.ia - Inteligência Artificial na Educação 🚀📚"
    
    Formato de saída: utilize títulos, tópicos, listas e destaque os pontos principais para facilitar a leitura e aplicação.
    
    ${objetivosSelecionados.length > 0 ? `Objetivos específicos selecionados: ${objetivosSelecionados.join(', ')}` : ''}
    Tom de linguagem: ${tomLinguagem === 'formal' ? 'formal e acadêmico' : 'leve, motivacional e inspirador'}
    ${modoPremium ? 'Capriche nos detalhes e traga sugestões de tendências educacionais atuais.' : ''}
    `

    try {
      const apiKey = import.meta.env.VITE_OPENAI_API_KEY
      const response = await axios.post('https://api.openai.com/v1/chat/completions', {
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.7,
      }, {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
      })

      const resposta = response.data.choices[0].message.content
      setPlanoGerado(resposta)
      salvarHistorico({
        tema, serie, disciplina, modelo: modeloPlano, plano: resposta, data: new Date().toISOString(),
        modoPremium
      })
      setSucesso('Plano gerado com sucesso!')
      setTimeout(() => setSucesso(''), 2000)
    } catch (error) {
      setErro('Erro ao gerar o plano. Verifique a chave de API.')
      setTimeout(() => setErro(''), 2000)
    } finally {
      setLoading(false)
    }
  }

  const baixarPlanoPdf = (texto, nomeArquivo = 'plano-aula-iaula.pdf') => {
    const doc = new jsPDF()
    const margin = 10
    const lineHeight = 10
    const maxLineWidth = 180
    let y = margin
    const lines = doc.splitTextToSize(texto, maxLineWidth)

    lines.forEach(line => {
      if (y > 280) {
        doc.addPage()
        y = margin
      }
      doc.text(line, margin, y)
      y += lineHeight
    })

    doc.save(nomeArquivo)
    setSucesso('Plano baixado como PDF!')
    setTimeout(() => setSucesso(''), 2000)
  }

  const abrirModal = (plano) => {
    setPlanoSelecionado(plano)
    setOpenModal(true)
  }

  const apagarPlano = (planoParaApagar) => {
    const novoHistorico = historico.filter((item) => item !== planoParaApagar)
    setHistorico(novoHistorico)
    localStorage.setItem('planejamentoHistorico', JSON.stringify(novoHistorico))
  }

  const limparHistorico = () => {
    if (window.confirm('Tem certeza que deseja apagar todo o histórico?')) {
      setHistorico([])
      localStorage.removeItem('planejamentoHistorico')
    }
  }

  const sugestaoTema = () => {
    const aleatorio = SUGESTOES_TEMA[Math.floor(Math.random() * SUGESTOES_TEMA.length)]
    setTema(aleatorio)
  }

  return (
    <div className="flex flex-col gap-8 p-8 max-w-6xl mx-auto w-full">
      {/* Opções de IA de planejamento */}
      <div className="flex flex-wrap gap-4 mb-2" role="radiogroup" aria-label="Modelos de IA de planejamento">
        {MODELOS_IA_PLANO.map((ia) => (
          <button
            key={ia.valor}
            aria-label={`Selecionar modelo ${ia.nome}`}
            onClick={() => setModeloIA(ia.valor)}
            className={`flex flex-col items-center px-4 py-3 rounded-lg border-2 shadow transition font-semibold
              ${modeloIA === ia.valor
                ? `${ia.cor} text-white border-indigo-700 scale-105`
                : ia.destaque
                  ? 'bg-white text-indigo-700 border-indigo-400 ring-2 ring-indigo-300'
                  : 'bg-white text-gray-800 border-gray-200 hover:bg-gray-50'}
              ${ia.destaque ? 'rounded-full' : ''}
            `}
            style={{ minWidth: 120 }}
          >
            <span className="text-2xl mb-1">{ia.icone}</span>
            <span>{ia.nome}</span>
            <span className="text-xs font-normal">{ia.descricao}</span>
            {ia.destaque && <span className="text-xs mt-1 font-bold text-indigo-700">Usada aqui</span>}
          </button>
        ))}
      </div>

      <h1 className="text-3xl font-bold text-gray-900 mb-2">Planejamento de Aula (IAula)</h1>

      {/* Dica rápida */}
      <div className="bg-indigo-50 rounded p-4 text-base text-indigo-800 mb-2">
        <strong>Dica:</strong> {DICAS[Math.floor(Math.random() * DICAS.length)]}
      </div>

      {/* Feedback visual */}
      {(erro || sucesso) && (
        <div className={`p-3 rounded text-center mb-2 ${erro ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
          {erro || sucesso}
        </div>
      )}

      {/* Formulário */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-white p-6 rounded-xl shadow border">
        <div className="flex flex-col gap-4">
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Tema da Aula *"
              className="border p-3 rounded-lg flex-1 text-lg"
              value={tema}
              onChange={(e) => setTema(e.target.value)}
            />
            <button
              onClick={sugestaoTema}
              className="px-4 py-2 bg-yellow-400 text-gray-900 rounded-lg font-bold hover:bg-yellow-300 transition"
              title="Gerar sugestão de tema"
            >
              🎲 Surpreenda-me!
            </button>
          </div>
          <input type="text" placeholder="Série/Ano" className="border p-3 rounded-lg text-lg" value={serie} onChange={(e) => setSerie(e.target.value)} />
          <input type="text" placeholder="Disciplina" className="border p-3 rounded-lg text-lg" value={disciplina} onChange={(e) => setDisciplina(e.target.value)} />
          <input type="text" placeholder="Duração" className="border p-3 rounded-lg text-lg" value={duracao} onChange={(e) => setDuracao(e.target.value)} />
          <button
            type="button"
            onClick={() => setOpenModalObjetivos(true)}
            className="px-4 py-2 bg-yellow-400 text-white rounded hover:bg-yellow-500"
          >
            Selecionar Objetivos 🎯
          </button>
        </div>
        <div className="flex flex-col gap-4">
          <select className="border p-3 rounded-lg text-lg" value={modeloPlano} onChange={(e) => setModeloPlano(e.target.value)}>
            <option value="tradicional">📚 Tradicional</option>
            <option value="ativo">🚀 Metodologias Ativas</option>
            <option value="invertido">🔄 Sala de Aula Invertida</option>
          </select>
          <textarea
            placeholder="Observações Especiais (opcional)"
            className="border p-3 rounded-lg text-lg"
            value={observacoes}
            onChange={(e) => setObservacoes(e.target.value)}
          />
          <div>
            <label className="text-sm font-semibold mb-1">Tom da Linguagem</label>
            <select className="border p-3 rounded-lg text-lg" value={tomLinguagem} onChange={(e) => setTomLinguagem(e.target.value)}>
              <option value="formal">📚 Formal</option>
              <option value="amigavel">💬 Amigável</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-semibold mb-1">Tipo de Plano</label>
            <div className="flex gap-2 mt-1">
              <button
                onClick={() => setModoPremium(false)}
                className={`px-4 py-2 rounded-lg text-lg ${modoPremium ? 'bg-gray-200' : 'bg-indigo-600 text-white'}`}
              >
                🎓 Normal
              </button>
              <button
                onClick={() => setModoPremium(true)}
                className={`px-4 py-2 rounded-lg text-lg ${modoPremium ? 'bg-yellow-500 text-white' : 'bg-gray-200'}`}
              >
                👑 Premium
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Botão Gerar */}
      <button
        onClick={gerarPlanoIA}
        disabled={loading}
        className="px-8 py-4 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 mt-4 text-xl font-bold w-full max-w-md mx-auto"
      >
        {loading ? 'IAula está preparando seu Plano de Aula... 🚀📚' : 'Gerar Plano IAula'}
      </button>

      {/* Plano Gerado */}
      {planoGerado && (
        <div className="mt-8 p-6 bg-white rounded-lg border shadow max-w-4xl mx-auto">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold mb-4 text-indigo-700">Plano Gerado:</h2>
            <button onClick={() => setPlanoGerado('')} className="text-red-600 hover:text-red-800 font-bold">Fechar ❌</button>
          </div>
          <pre className="whitespace-pre-wrap text-gray-800 text-base">{planoGerado}</pre>
          <div className="mt-4 flex gap-3">
            <button
              onClick={() => baixarPlanoPdf(planoGerado)}
              className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
            >
              Baixar Plano em PDF
            </button>
          </div>
        </div>
      )}

      {/* Histórico de Planos Gerados */}
      {historico.length > 0 && (
        <div className="mt-10">
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-xl font-bold text-gray-800">📚 Histórico de Planos Gerados</h2>
            <button
              onClick={limparHistorico}
              className="px-4 py-2 bg-red-100 text-red-700 rounded hover:bg-red-200 text-sm font-semibold"
            >
              Limpar tudo
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {historico.map((item, index) => (
              <div key={index} className="bg-white border rounded-lg shadow p-4 flex flex-col gap-2">
                <div className="flex justify-between items-center">
                  <div>
                    <div className="font-bold text-indigo-700">{item.tema}</div>
                    <div className="text-xs text-gray-500">{item.serie} • {item.disciplina}</div>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs font-bold ${item.modoPremium ? 'bg-yellow-200 text-yellow-800' : 'bg-indigo-100 text-indigo-700'}`}>
                    {item.modoPremium ? 'Premium' : 'Normal'}
                  </span>
                </div>
                <div className="text-xs text-gray-400 mb-2">{new Date(item.data).toLocaleDateString()}</div>
                <div className="flex gap-2 mt-auto">
                  <button
                    onClick={() => abrirModal(item.plano)}
                    title="Visualizar"
                    className="text-blue-600 hover:text-blue-800 text-lg"
                  >
                    🔍
                  </button>
                  <button
                    onClick={() => baixarPlanoPdf(item.plano, `plano-${index + 1}.pdf`)}
                    title="Baixar PDF"
                    className="text-green-600 hover:text-green-800 text-lg"
                  >
                    📥
                  </button>
                  <button
                    onClick={() => apagarPlano(item)}
                    title="Apagar"
                    className="text-red-600 hover:text-red-800 text-lg"
                  >
                    🗑️
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal Visualização e Modal de Objetivos */}
      <Modal open={openModal} setOpen={setOpenModal} plano={planoSelecionado} />
      <ModalObjetivos open={openModalObjetivos} setOpen={setOpenModalObjetivos} objetivosSelecionados={objetivosSelecionados} setObjetivosSelecionados={setObjetivosSelecionados} />

      <footer className="mt-10 text-center text-xs text-gray-400">
        IAula — Planejamento de aulas com Inteligência Artificial. Para uso educacional.
      </footer>
    </div>
  )
}