import { useState } from 'react';
import modelosProntos from '../data/modelosProntos.jsx'; // Importando o arquivo com os dados
import { jsPDF } from 'jspdf';
import ModalCriarModelo from '../components/ModalCriarModelo';
import ModalVisualizarModelo from '../components/ModalVisualizarModelo'; // Importando o modal de visualização
import Toast from '../components/Toast';

export default function Modelos() {
  const [filtroTipo, setFiltroTipo] = useState('todos');
  const [filtroDisciplina, setFiltroDisciplina] = useState('todos');
  const [favoritos, setFavoritos] = useState([]);
  const [openModal, setOpenModal] = useState(false);
  const [openModalVisualizar, setOpenModalVisualizar] = useState(false); // Estado para abrir o modal de visualização
  const [modeloSelecionado, setModeloSelecionado] = useState(null); // Modelo selecionado para visualização
  const [toastMessage, setToastMessage] = useState('');

  const baixarPdf = (plano, nome = 'plano-iaula.pdf') => {
    const doc = new jsPDF();
    const margin = 10;
    const lineHeight = 10;
    const maxLineWidth = 180;
    let y = margin;
    const lines = doc.splitTextToSize(plano, maxLineWidth);

    lines.forEach((line) => {
      if (y > 280) {
        doc.addPage();
        y = margin;
      }
      doc.text(line, margin, y);
      y += lineHeight;
    });

    doc.save(nome);
    setToastMessage('Plano baixado com sucesso!');
  };

  const favoritarModelo = (modelo) => {
    if (!favoritos.find(item => item.id === modelo.id)) {
      setFavoritos([...favoritos, modelo]);
      setToastMessage('Plano adicionado aos Favoritos!');
    }
  };

  const modelosFiltrados = modelosProntos.filter((item) => {
    const tipoOk = filtroTipo === 'todos' || item.tipo === filtroTipo;
    const disciplinaOk = filtroDisciplina === 'todos' || item.disciplina === filtroDisciplina;
    return tipoOk && disciplinaOk;
  });

  const abrirModalVisualizar = (modelo) => {
    setModeloSelecionado(modelo);
    setOpenModalVisualizar(true); // Abre o modal de visualização
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-indigo-700">Modelos de Planos Prontos 📚</h1>
        <button
          onClick={() => setOpenModal(true)}
          className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
        >
          Criar Modelo Próprio
        </button>
      </div>

      {/* Filtros */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <select className="border p-2 rounded-lg" value={filtroTipo} onChange={(e) => setFiltroTipo(e.target.value)}>
          <option value="todos">Todos (Fundamental e Médio)</option>
          <option value="fundamental">Ensino Fundamental</option>
          <option value="medio">Ensino Médio</option>
        </select>
        <select className="border p-2 rounded-lg" value={filtroDisciplina} onChange={(e) => setFiltroDisciplina(e.target.value)}>
          <option value="todos">Todas as Disciplinas</option>
          <option value="Matemática">Matemática</option>
          <option value="História">História</option>
          <option value="Geografia">Geografia</option>
          <option value="Ciências">Ciências</option>
          <option value="Português">Português</option>
          <option value="Inglês">Inglês</option>
        </select>
      </div>

      {/* Lista de Modelos */}
      <div className="space-y-6">
        {modelosFiltrados.map((modelo) => (
          <div key={modelo.id} className="p-4 border rounded-lg shadow hover:shadow-md transition">
            <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
              <div>
                <h2 className="text-xl font-semibold text-gray-800">{modelo.titulo}</h2>
                <p className="text-gray-500 text-sm">{modelo.descricao}</p>
                <div className="flex gap-2 mt-2">
                  <span className="text-xs bg-indigo-100 text-indigo-800 px-2 py-1 rounded">{modelo.tipo.toUpperCase()}</span>
                  <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">{modelo.disciplina}</span>
                </div>
              </div>
              <div className="flex gap-2 flex-wrap">
                <button
                  onClick={() => abrirModalVisualizar(modelo)} // Botão de visualizar
                  className="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 text-sm"
                >
                  👁️ Visualizar
                </button>
                <button
                  onClick={() => baixarPdf(modelo.plano, `plano-${modelo.id}.pdf`)}
                  className="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 text-sm"
                >
                  📄 Baixar
                </button>
                <button
                  onClick={() => favoritarModelo(modelo)}
                  className="px-3 py-1 bg-yellow-400 text-white rounded hover:bg-yellow-500 text-sm"
                >
                  ⭐ Favoritar
                </button>
              </div>
            </div>
          </div>
        ))}
        {modelosFiltrados.length === 0 && (
          <div className="text-gray-600 text-center mt-6">Nenhum modelo encontrado para os filtros selecionados.</div>
        )}
      </div>

      {/* Modal de Criar Modelo */}
      <ModalCriarModelo open={openModal} setOpen={setOpenModal} setToastMessage={setToastMessage} />

      {/* Modal de Visualizar Modelo */}
      <ModalVisualizarModelo 
        open={openModalVisualizar} 
        setOpen={setOpenModalVisualizar} 
        modelo={modeloSelecionado} 
        baixarPdf={baixarPdf}
      />

      {/* Toast de Alertas */}
      {toastMessage && <Toast message={toastMessage} onClose={() => setToastMessage('')} />}
    </div>
  );
}
