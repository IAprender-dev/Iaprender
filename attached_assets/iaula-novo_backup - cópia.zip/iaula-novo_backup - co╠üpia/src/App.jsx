import { useState, useEffect } from "react";
import { Routes, Route, useLocation, Navigate } from "react-router-dom";
import Sidebar from "./components/SidebarModern";

import Home from "./pages/Home";
import Apoio from "./pages/Apoio";
import Planejamento from "./pages/Planejamento";
import ModelosProntos from "./pages/ModelosProntos";
import CriarImagemIA from "./pages/CriarImagemIA";
import CorrecaoProvas from "./pages/CorrecaoProvas";
import TutorVirtual from "./pages/TutorVirtual";
import GeradorAtividades from "./pages/GeradorAtividades";
import GeracaodeMateriais from "./pages/GeracaodeMateriais";
import OrganizadorAula from "./pages/OrganizadorAula";
import Login from "./pages/Login";
import PrivateRoute from "./components/PrivateRoute";

export default function App() {
  const [autenticado, setAutenticado] = useState(localStorage.getItem("auth") === "true");
  const location = useLocation();

  useEffect(() => {
    const onStorage = () => setAutenticado(localStorage.getItem("auth") === "true");
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  useEffect(() => {
    setAutenticado(localStorage.getItem("auth") === "true");
  }, [location]);

  const mostrarSidebar = autenticado && location.pathname !== "/login";

  return (
    <div className="flex h-screen overflow-hidden">
      {mostrarSidebar && <Sidebar />}
      <div className="flex-1 overflow-y-auto bg-gray-50 dark:bg-gray-800 p-6">
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<PrivateRoute><Home /></PrivateRoute>} />
          <Route path="/apoio" element={<PrivateRoute><Apoio /></PrivateRoute>} />
          <Route path="/tutor-virtual" element={<PrivateRoute><TutorVirtual /></PrivateRoute>} />
          <Route path="/criar-imagem" element={<PrivateRoute><CriarImagemIA /></PrivateRoute>} />
          <Route path="/gerador-atividades" element={<PrivateRoute><GeradorAtividades /></PrivateRoute>} />
          <Route path="/materiais-didaticos" element={<PrivateRoute><GeracaodeMateriais /></PrivateRoute>} />
          <Route path="/organizador-aula" element={<PrivateRoute><OrganizadorAula /></PrivateRoute>} />
          <Route path="/correcao-provas" element={<PrivateRoute><CorrecaoProvas /></PrivateRoute>} />
          <Route path="/planejamento" element={<PrivateRoute><Planejamento /></PrivateRoute>} />
          <Route path="/modelos-prontos" element={<PrivateRoute><ModelosProntos /></PrivateRoute>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </div>
  );
}
