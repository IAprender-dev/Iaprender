const modelosProntos = [
  {
    id: 1,
    titulo: "Plano de Matemática - Frações",
    descricao: "Plano para ensinar conceitos básicos de frações.",
    tipo: "fundamental",
    disciplina: "Matemática",
    plano: "Plano de aula sobre frações, incluindo atividades práticas e avaliação formativa."
  },
  {
    id: 2,
    titulo: "Plano de História - Revolução Francesa",
    descricao: "Plano sobre a Revolução Francesa e seus impactos.",
    tipo: "medio",
    disciplina: "História",
    plano: "Plano de aula detalhado sobre causas e consequências da Revolução Francesa."
  },
  {
    id: 3,
    titulo: "Plano de Geografia - Climas do Mundo",
    descricao: "Plano abordando os principais tipos de clima.",
    tipo: "fundamental",
    disciplina: "Geografia",
    plano: "Plano para ensinar climas tropicais, temperados e polares com atividades práticas."
  },
  {
    id: 4,
    titulo: "Plano de Ciências - Corpo Humano",
    descricao: "Plano para ensinar sistemas do corpo humano.",
    tipo: "fundamental",
    disciplina: "Ciências",
    plano: "Plano explicando sistemas respiratório, circulatório e digestório com experimentos simples."
  },
  {
    id: 5,
    titulo: "Plano de Português - Redação Narrativa",
    descricao: "Plano focado em desenvolver a habilidade de escrever narrativas.",
    tipo: "medio",
    disciplina: "Português",
    plano: "Plano para produção de narrativas, explorando estrutura de começo, meio e fim."
  }
];

export default modelosProntos;
