import { useTheme } from "../context/ThemeContext";
import { Sun, Moon, ChevronDown } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';

export default function Header() {
  const { theme, toggleTheme } = useTheme();
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef(null);

  const usuario = {
    nome: "IAula.ia",
    foto: "https://via.placeholder.com/40", // Trocar depois pela foto real
  };

  function handleLogout() {
    localStorage.removeItem("auth");
    window.location.href = "/login";
    setOpen(false); // Fecha o menu também
  }

  // Detectar clique fora do dropdown
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <header className="w-full bg-white dark:bg-gray-900 border-b dark:border-gray-700 flex items-center justify-between px-6 py-4 shadow-sm sticky top-0 z-50">
      
      {/* Botão de Tema */}
      <div className="flex items-center gap-3">
        <button
          onClick={toggleTheme}
          className="p-2 rounded-md bg-indigo-100 dark:bg-indigo-900 hover:bg-indigo-200 dark:hover:bg-indigo-800 transition-all duration-300"
        >
          {theme === "dark" ? (
            <Sun size={20} className="text-yellow-400" />
          ) : (
            <Moon size={20} className="text-indigo-700" />
          )}
        </button>
      </div>

      {/* Usuário + Dropdown */}
      <div className="relative" ref={dropdownRef}>
        <button
          onClick={() => setOpen(!open)}
          className="flex items-center gap-2 focus:outline-none"
        >
          <img
            src={usuario.foto}
            alt="Usuário"
            className="rounded-full w-10 h-10"
          />
          <span className="hidden sm:block font-semibold text-gray-900 dark:text-gray-100">{usuario.nome}</span>
          <ChevronDown size={16} className="text-gray-600 dark:text-gray-300" />
        </button>

        {/* Menu Dropdown */}
        {open && (
          <div
            className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg overflow-hidden z-20"
            onMouseLeave={() => setOpen(false)} // <<< Fecha ao sair com o mouse
          >
            <a
              href="#"
              className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
              onClick={() => setOpen(false)} // Fecha também se clicar em Perfil
            >
              Perfil
            </a>
            <button
              onClick={handleLogout}
              className="w-full text-left block px-4 py-2 text-sm text-red-500 hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              Sair
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
