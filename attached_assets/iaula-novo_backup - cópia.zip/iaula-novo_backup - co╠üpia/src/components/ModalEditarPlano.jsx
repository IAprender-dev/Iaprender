import { Dialog, Transition } from '@headlessui/react'
import { Fragment, useState } from 'react'
import { jsPDF } from 'jspdf'

export default function ModalEditarPlano({ open, setOpen, planoSelecionado }) {
  const [conteudoEditado, setConteudoEditado] = useState('')

  const fecharModal = () => {
    setOpen(false)
    setConteudoEditado('')
  }

  const baixarPdf = () => {
    const doc = new jsPDF()
    const lines = doc.splitTextToSize(conteudoEditado || planoSelecionado.plano, 180)
    let y = 10
    lines.forEach(line => {
      if (y > 280) {
        doc.addPage()
        y = 10
      }
      doc.text(line, 10, y)
      y += 10
    })
    doc.save(`plano-${planoSelecionado.titulo}.pdf`)
  }

  const salvarNoHistorico = () => {
    const historico = JSON.parse(localStorage.getItem('planejamentoHistorico')) || []
    const novoHistorico = [
      {
        tema: planoSelecionado.titulo,
        serie: '',
        disciplina: '',
        modelo: 'modelo pronto',
        plano: conteudoEditado || planoSelecionado.plano,
        data: new Date().toISOString(),
      },
      ...historico,
    ]
    localStorage.setItem('planejamentoHistorico', JSON.stringify(novoHistorico))
    alert('Plano salvo no seu histórico com sucesso!')
    fecharModal()
  }

  return (
    <Transition.Root show={open} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={setOpen}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-gray-900 bg-opacity-50 transition-opacity" />
        </Transition.Child>

        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <Dialog.Panel className="relative w-full max-w-3xl transform rounded-lg bg-white p-6 shadow-xl transition-all">
            <Dialog.Title className="text-lg font-bold text-gray-900 mb-4">
              ✏️ Editar Plano: {planoSelecionado?.titulo}
            </Dialog.Title>

            <textarea
              className="w-full h-80 p-4 border rounded-lg text-gray-800"
              value={conteudoEditado || planoSelecionado?.plano}
              onChange={(e) => setConteudoEditado(e.target.value)}
            />

            <div className="flex justify-end gap-3 mt-6">
              <button onClick={baixarPdf} className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 text-sm">
                Baixar PDF
              </button>
              <button onClick={salvarNoHistorico} className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm">
                Salvar no Histórico
              </button>
              <button onClick={fecharModal} className="px-4 py-2 bg-gray-400 text-white rounded hover:bg-gray-500 text-sm">
                Fechar
              </button>
            </div>
          </Dialog.Panel>
        </div>
      </Dialog>
    </Transition.Root>
  )
}
