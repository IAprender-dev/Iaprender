export default function PageWrapper({ children }) {
    return (
      <div className="max-w-6xl mx-auto w-full min-h-[calc(100vh-80px)] px-6 py-8">
        {children}
      </div>
    );
  }
  