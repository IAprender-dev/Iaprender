import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { 
  Home, BookOpen, Calendar, FileText, Settings, HelpCircle, 
  Image, PenLine, Bot, ListChecks, BookCopy, Sun, Moon 
} from 'lucide-react';
import { useTheme } from "../context/ThemeContext";

export default function SidebarModern() {
  const navigate = useNavigate();
  const [expandido, setExpandido] = useState(false);
  const { theme, toggleTheme } = useTheme();

  function handleLogout() {
    localStorage.removeItem("auth");
    navigate("/login");
  }

  return (
    <div
      className={`h-screen bg-white dark:bg-gray-900 border-r dark:border-gray-700 flex flex-col justify-between transition-all duration-300 ${expandido ? 'w-72' : 'w-20'}`}
      onMouseEnter={() => setExpandido(true)}
      onMouseLeave={() => setExpandido(false)}
    >
      <div className="p-4 space-y-8">
        {/* Logo e Nome */}
        <div className="flex items-center gap-3">
          <img src="/IAula.PNG" alt="Logo IAula" className="w-10 h-10" />
          {expandido && <span className="text-2xl font-bold text-indigo-600">IAula</span>}
        </div>

        {/* Menu de Navegação */}
        <div className="space-y-2">
          {expandido && <div className="text-xs font-semibold text-gray-400 uppercase">Ferramentas</div>}
          <nav className="flex flex-col gap-3 mt-2">
            <SidebarItem to="/" icon={<Home size={20} />} label="Home" expandido={expandido} />
            <SidebarItem to="/apoio" icon={<BookOpen size={20} />} label="Apoio aos Estudos" expandido={expandido} />
            <SidebarItem to="/tutor-virtual" icon={<Bot size={20} />} label="Tutor Virtual" expandido={expandido} />
            <SidebarItem to="/criar-imagem" icon={<Image size={20} />} label="Criar Imagem" expandido={expandido} />
            <SidebarItem to="/gerador-atividades" icon={<ListChecks size={20} />} label="Gerador de Atividades" expandido={expandido} />
            <SidebarItem to="/materiais-didaticos" icon={<BookCopy size={20} />} label="Materiais Didáticos" expandido={expandido} />
            <SidebarItem to="/organizador-aula" icon={<Calendar size={20} />} label="Organizador de Aula" expandido={expandido} />
            <SidebarItem to="/correcao-provas" icon={<PenLine size={20} />} label="Correção de Provas" expandido={expandido} />
            <SidebarItem to="/planejamento" icon={<Calendar size={20} />} label="Planejamento" expandido={expandido} />
            <SidebarItem to="/modelos-prontos" icon={<FileText size={20} />} label="Modelos de Planejamento" expandido={expandido} />
          </nav>
        </div>

        <div className="pt-6 space-y-2">
          {expandido && <div className="text-xs font-semibold text-gray-400 uppercase">Administração</div>}
          <nav className="flex flex-col gap-3 mt-2">
            <SidebarItem to="/configuracoes" icon={<Settings size={20} />} label="Configurações" expandido={expandido} />
            <SidebarItem to="/suporte" icon={<HelpCircle size={20} />} label="Suporte" expandido={expandido} />
          </nav>
        </div>
      </div>

      {/* Rodapé com Tema e Usuário */}
      <div className="p-4 border-t dark:border-gray-700 flex flex-col items-center gap-4">
        <button
          onClick={toggleTheme}
          className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition"
        >
          {theme === "dark" ? <Sun size={20} className="text-yellow-400" /> : <Moon size={20} className="text-indigo-700" />}
        </button>
        <img src="https://via.placeholder.com/40" alt="Usuário" className="rounded-full w-10 h-10" />
        {expandido && (
          <div className="text-center">
            <div className="font-semibold text-gray-900 dark:text-white">IAula.ia</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Administrador</div>
            <button
              onClick={handleLogout}
              className="text-xs text-red-500 underline mt-1"
            >
              Sair
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function SidebarItem({ to, icon, label, expandido }) {
  return (
    <Link to={to} className="flex items-center gap-3 text-gray-700 dark:text-gray-300 hover:text-indigo-600 dark:hover:text-indigo-400 transition">
      {icon}
      {expandido && <span>{label}</span>}
    </Link>
  );
}
