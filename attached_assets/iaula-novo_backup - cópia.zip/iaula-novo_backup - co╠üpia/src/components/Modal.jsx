import { Fragment } from "react";
import { Dialog, Transition } from "@headlessui/react";
import { jsPDF } from "jspdf";

export default function Modal({ open, setOpen, plano }) {
  const salvarPdf = () => {
    const doc = new jsPDF();
    let y = 10;

    plano.split("\n").forEach((linha) => {
      doc.text(linha, 10, y);
      y += 10;
      if (y > 270) {
        doc.addPage();
        y = 10;
      }
    });

    doc.save("plano-de-aula-iaula.pdf");
  };

  return (
    <Transition.Root show={open} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={setOpen}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
        </Transition.Child>

        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4 sm:p-6 lg:p-8 text-center">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
              <Dialog.Panel className="relative transform overflow-hidden rounded-lg bg-white px-6 pt-6 pb-4 text-left shadow-xl transition-all w-full max-w-4xl">
                <div className="flex justify-between items-center mb-4">
                  <Dialog.Title as="h3" className="text-xl font-semibold leading-6 text-gray-900">
                    Plano Gerado
                  </Dialog.Title>
                  <div className="flex gap-2">
                    <button
                      onClick={salvarPdf}
                      className="rounded-md bg-green-600 px-4 py-2 text-sm font-semibold text-white hover:bg-green-700 transition"
                    >
                      Salvar PDF
                    </button>
                    <button
                      onClick={() => setOpen(false)}
                      className="rounded-md bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700 transition"
                    >
                      Fechar
                    </button>
                  </div>
                </div>

                <div className="overflow-y-auto max-h-[70vh] border rounded-lg p-4 bg-gray-50 text-gray-800 whitespace-pre-line">
                  {plano}
                </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition.Root>
  );
}
