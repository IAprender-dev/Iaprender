import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

export default function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    const container = document.querySelector('main') || document.querySelector('.flex-1');
    if (container) {
      container.scrollTo(0, 0);
    } else {
      window.scrollTo(0, 0); // fallback
    }
  }, [pathname]);

  return null;
}
