import { Navigate } from "react-router-dom";

export default function PrivateRoute({ children }) {
  const autenticado = localStorage.getItem("auth") === "true";
  return autenticado ? children : <Navigate to="/login" replace />;
}