import { Dialog, Transition } from '@headlessui/react'
import { Fragment } from 'react'

const objetivos = [
  "Desenvolver habilidades de pensamento crítico",
  "Promover a colaboração em grupo",
  "Estimular a criatividade e inovação",
  "Aplicar conhecimentos em situações práticas",
  "Fomentar a autonomia dos estudantes",
  "Integrar tecnologia nas atividades educacionais",
  "Valorizar a diversidade e inclusão",
  "Desenvolver competências socioemocionais",
  "Incentivar a pesquisa e investigação",
  "Fortalecer a comunicação oral e escrita",
]

export default function ModalObjetivos({ open, setOpen, objetivosSelecionados, setObjetivosSelecionados }) {

  const toggleObjetivo = (objetivo) => {
    if (objetivosSelecionados.includes(objetivo)) {
      setObjetivosSelecionados(objetivosSelecionados.filter(item => item !== objetivo))
    } else {
      setObjetivosSelecionados([...objetivosSelecionados, objetivo])
    }
  }

  const fecharModal = () => {
    setOpen(false)
  }

  return (
    <Transition.Root show={open} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={setOpen}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-gray-900 bg-opacity-50 transition-opacity" />
        </Transition.Child>

        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <Dialog.Panel className="relative w-full max-w-2xl transform rounded-lg bg-white p-6 shadow-xl transition-all">
            <Dialog.Title className="text-lg font-bold text-gray-900 mb-4">Selecionar Objetivos 🎯</Dialog.Title>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
              {objetivos.map((objetivo, index) => (
                <div key={index} className="flex items-center">
                  <input
                    type="checkbox"
                    id={`objetivo-${index}`}
                    className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                    checked={objetivosSelecionados.includes(objetivo)}
                    onChange={() => toggleObjetivo(objetivo)}
                  />
                  <label htmlFor={`objetivo-${index}`} className="ml-2 block text-sm text-gray-700">
                    {objetivo}
                  </label>
                </div>
              ))}
            </div>

            <div className="mt-6 flex justify-end gap-2">
              <button
                type="button"
                onClick={fecharModal}
                className="rounded-md bg-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-400"
              >
                Fechar
              </button>
            </div>
          </Dialog.Panel>
        </div>
      </Dialog>
    </Transition.Root>
  )
}
